# options(java.parameters = "-Xmx16g")
library(rJava)
jars <- list.files("distlib","*.jar",full.names=TRUE)
.jinit()
.jaddClassPath(jars)





##########################
#### Not exported
##########################

shallot.msg <- function(x,fmtstr="%Y-%m-%d %r") {
  cat(format(Sys.time(),fmtstr),": ",x,"\n",sep="")
}

shallot.gc <- function() {
  gc(FALSE)
  .jcall("java/lang/System","V","gc")
}

shallot.trace <- function(expr) {
  tryCatch(expr,Exception = function(e){
    cat(paste(unlist(lapply(.jevalArray(e$jobj$getStackTrace()),function(x) { x$toString() })),collapse="\n"),"\n",sep="")
  })  
}

shallot.matrixOfPartitonsToShallotSamples <- function(samples) {
  interface <- .jnew("org.ddahl.shallot.r.RInterface$")
  samples <- .jcall(interface,"Lscala/collection/immutable/List;","matrixToPartitions",.jarray(samples,dispatch=TRUE))
  result <- list(jobjRef=list(interface=interface,samples=samples))
  class(result) <- "shallot.samples"
  samples <- result
}





##########################
#### Exported
##########################

# Adjusted Rand Index
adj.rand.index <- function(c1,c2) {
  n <- length(c1)
  if ( length(c2) != n ) stop("Clustering must be the same length.")
  t1  <- table(c1)
  t2  <- table(c2)
  t12 <- table(c1,c2)
  expected <- sum(choose(t1,2)) * sum(choose(t2,2)) / choose(n,2)
  numerator <- sum(choose(t12,2)) - expected
  denominator <- 0.5*(sum(choose(t1,2))+sum(choose(t2,2))) - expected
  numerator / denominator
}





# Mass
mass <- function(...,fixed=TRUE) {
  x <- c(...)
  value <- 1.2
  shape <- 2.5
  rate <- 2
  if ( length(x) == 0 ) {
  } else if ( length(x) == 1 ) {
    value <- as.double(x[1])
  } else if ( length(x) == 2 ) {
    if ( fixed ) stop("fixed should be FALSE if distribution parameters are specified.")
    shape <- as.double(x[1])
    rate <- as.double(x[2])
  } else stop("Incorrect number of arguments.")
  result <- list(value=value,shape=shape,rate=rate,fixed=fixed)
  class(result) <- "shallot.mass"
  result
}

print.shallot.mass <- function(x, ...) {
  if ( x$fixed ) cat("mass fixed at ",x$value,"\n",sep="")
  else cat("mass sampled from Gamma(shape=",x$shape,",rate=",x$rate,")\n",sep="")
}





# Discount
discount <- function(...,fixed=TRUE) {
  x <- c(...)
  value <- 0.05
  shape1 <- 1
  shape2 <- 1
  if ( length(x) == 0 ) {
  } else if ( length(x) == 1 ) {
    value <- as.double(x[1])
  } else if ( length(x) == 2 ) {
    if ( fixed ) stop("fixed should be FALSE if distribution parameters are specified.")
    shape1 <- as.double(x[1])
    shape2 <- as.double(x[2])
  } else stop("Incorrect number of arguments.")
  result <- list(value=value,shape1=shape1,shape2=shape2,fixed=fixed)
  class(result) <- "shallot.discount"
  result
}

print.shallot.discount <- function(x, ...) {
  if ( x$fixed ) cat("discount fixed at ",x$value,"\n",sep="")
  else cat("discount sampled from Beta(shape1=",x$shape1,",shape2=",x$shape2,")\n",sep="")
}





# Similarity
similarity <- function(x, as.distance=TRUE) {
  similarityCO <- .jnew("org.ddahl.shallot.parameter.Similarity$")
  y <- .jarray(as.matrix(x),dispatch=TRUE)
  jobjRef <- if ( as.distance ) .jcall(similarityCO,"Lorg/ddahl/shallot/parameter/Similarity;","byReciprocation",y)
  else .jcall(similarityCO,"Lorg/ddahl/shallot/parameter/Similarity;","apply",y)
  result <- list(jobjRef=jobjRef,n.items=.jcall(jobjRef,"I","nItems"))
  class(result) <- "shallot.similarity"
  result
}

print.shallot.similarity <- function(x, ...) {
  cat("similarity for ",x$n.items," items\n",sep="")
}

as.matrix.shallot.similarity <- function(x, ...) {
  .jcall(x$jobjRef,"[[D","toArray",simplify=TRUE)
}





# Permutation
permutation <- function(...,n.items=NULL,fixed=TRUE) {
  x <- c(...) - 1
  permutationCO <- .jnew("org.ddahl.shallot.parameter.Permutation$")
  if ( length(x) == 0 ) {
    if ( is.null(n.items) ) stop("'n.items' must be specified if permutation is not given.")
    if ( fixed ) stop("'fixed' must be FALSE if permutation is not given.")
    jobjRef <- .jcall(permutationCO,"Lorg/ddahl/shallot/parameter/Permutation;","apply",as.integer(seq(n.items)-1))
  } else {
    if ( is.null(n.items) ) n.items <- length(x)
    if ( n.items != length(x) ) stop("'n.items' is not equal to the length of the permutation.")
    jobjRef <- .jcall(permutationCO,"Lorg/ddahl/shallot/parameter/Permutation;","apply",as.integer(x))
  }
  result <- list(n.items=n.items,fixed=fixed,jobjRef=jobjRef)
  class(result) <- "shallot.permutation"
  result
}

print.shallot.permutation <- function(x, ...) {
  if ( x$fixed ) {
    y <- .jcall(x$jobjRef,"S","toString")
    width <- 50
    if ( nchar(y) > width ) y <- paste(strtrim(y,width-3),"...",sep="")
    cat("permutation of ",x$n.items," items fixed at ",y,"\n",sep="")
  }
  else cat("permutation of ",x$n.items," items sampled uniformly\n",sep="")
}





# Temperature
temperature <- function(...,fixed=TRUE) {
  x <- c(...)
  value <- 3
  shape <- 2
  rate <- 0.5
  if ( length(x) == 0 ) {
  } else if ( length(x) == 1 ) {
    if ( ! fixed ) stop("fixed should be TRUE if value is specified.")
    value <- as.double(x[1])
  } else if ( length(x) == 2 ) {
    if ( fixed ) stop("fixed should be FALSE if distribution parameters are specified.")
    shape <- as.double(x[1])
    rate <- as.double(x[2])
  } else stop("Incorrect number of arguments.")
  result <- list(value=value,shape=shape,rate=rate,fixed=fixed)
  class(result) <- "shallot.temperature"
  result
}

print.shallot.temperature <- function(x, ...) {
  if ( x$fixed ) cat("temperature fixed at ",x$value,"\n",sep="")
  else cat("temperature sampled from Gamma(shape=",x$shape,",rate=",x$rate,")\n",sep="")
}





# Attraction
attraction <- function(similarity, permutation, temperature) {
  fixed <- permutation$fixed && temperature$fixed
  jobjRef <- if ( fixed ) {
    temperatureCO <- .jnew("org.ddahl.shallot.parameter.Temperature$")
    t <- .jcall(temperatureCO,"Lorg/ddahl/shallot/parameter/Temperature;","apply",as.double(temperature$value))
    p <- permutation$jobjRef
    attractionCO <- .jnew("org.ddahl.shallot.distribution.Attraction$")
    .jcall(attractionCO,"Lorg/ddahl/shallot/distribution/Attraction;","apply",similarity$jobjRef,permutation$jobjRef,t)
  } else NULL
  result <- list(n.items=similarity$n.items, similarity=similarity, permutation=permutation, temperature=temperature, fixed=fixed, jobjRef=jobjRef)
  class(result) <- "shallot.attraction"
  result
}

print.shallot.attraction <- function(x, ...) {
  cat("attraction for ",x$n.items," items:\n",sep="")
  cat("  ")
  print(x$similarity)
  cat("  ")
  print(x$permutation)
  cat("  ")
  print(x$temperature)
}

as.matrix.shallot.attraction <- function(x, ...) {
  .jcall(x$jobjRef,"[[D","toArray",simplify=TRUE)
}





# Ewens
ewens <- function(mass, n.items) {
  result <- list(mass=mass,n.items=n.items)
  class(result) <- c("shallot.distribution","ewens")
  result
}

print.shallot.distribution.ewens <- function(x, ...) {
  cat("Ewens distribution with:\n")
  cat("  ",x$n.items," items\n",sep="")
  cat("  ")
  print(x$mass)
}





# Ewens Pitman
ewens.pitman <- function(mass, discount, n.items) {
  result <- list(mass=mass,discount=discount,n.items=n.items)
  class(result) <- c("shallot.distribution","ewensPitman")
  result
}

print.shallot.distribution.ewensPitman <- function(x, ...) {
  cat("Ewens Pitman distribution with:\n")
  cat("  ",x$n.items," items\n",sep="")
  cat("  ")
  print(x$mass)
  cat("  ")
  print(x$discount)
}





# Ewens Attraction
ewens.attraction <- function(mass, attraction) {
  result <- list(mass=mass,attraction=attraction,n.items=attraction$n.items)
  class(result) <- c("shallot.distribution","ewensAttraction")
  result
}

print.shallot.distribution.ewensAttraction <- function(x, ...) {
  cat("Ewens distribution with:\n")
  cat("  ")
  print(x$mass)
  x <- capture.output(print(x$attraction))
  cat(paste("  ",x,"\n",sep=""))
}





# MCMC tuning
mcmc.parameters <- function(log.density.NAME=NULL,sample.NAME=NULL,mass.rw.sd=0.5,discount.rw.sd=0.1,permutation.grab.size=10,temperature.rw.sd=0.5,n.iterations.per.sample=1) {
  sampling.model <- if ( is.null(log.density.NAME) ) NULL
  else {
    callBackEngine <- .jengine(start=TRUE)
    usesPredictiveDensity <- FALSE
    if ( is.null(sample.NAME) ) {
      usesPredictiveDensity <- TRUE
      sample.NAME <- ""
    }
    .jcall("org/ddahl/shallot/r/RAdapter","Lorg/ddahl/shallot/r/RAdapter;","apply",callBackEngine,as.logical(usesPredictiveDensity),log.density.NAME,sample.NAME)
  }
  result <- list(
    mass.rw.sd=as.double(mass.rw.sd),
    discount.rw.sd=as.double(discount.rw.sd),
    permutation.grab.size=as.integer(permutation.grab.size),
    temperature.rw.sd=as.double(temperature.rw.sd),
    n.iterations.per.sample=as.integer(n.iterations.per.sample),
    sampling.model=sampling.model)
  class(result) <- "shallot.mcmc.parameters"
  result
}

mcmc.parameters()





# collect
collect <- function(x,n.draws=1000,mcmc.parameters=NULL,parallel=TRUE,seed=NULL) {
  start.time <- proc.time()
  if ( inherits(x,"shallot.distribution") ) {
    interface <- .jnew("org.ddahl.shallot.r.RInterface$")
    pm <- x
    rdg <- .jnew("org/apache/commons/math3/random/RandomDataGenerator")
    if ( ! is.null(seed) ) rdg$reSeed(.jlong(seed))
    distribution.name <- paste(class(pm),collapse=".")
    mass <- as.double(pm$mass$value)
    massShape <- as.double(pm$mass$shape)
    massRate <- as.double(pm$mass$rate)
    massFixed <- as.logical(pm$mass$fixed)
    if ( distribution.name == "shallot.distribution.ewensPitman" ) {
      discount <- as.double(pm$discount$value)
      discountShape1 <- as.double(pm$discount$shape1)
      discountShape2 <- as.double(pm$discount$shape2)
      discountFixed <- as.logical(pm$discount$fixed)
    } else {
      discount <- 0.0
      discountShape1 <- 0.0
      discountShape2 <- 0.0
      discountFixed <- TRUE
    }
    if ( distribution.name == "shallot.distribution.ewensAttraction" ) {
      similarity <- pm$attraction$similarity$jobjRef
      permutation <- pm$attraction$permutation$jobjRef
      permutationFixed <- as.logical(pm$attraction$permutation$fixed)
      temperature <- as.double(pm$attraction$temperature$value)
      temperatureShape <- as.double(pm$attraction$temperature$shape)
      temperatureRate <- as.double(pm$attraction$temperature$rate)
      temperatureFixed <- as.logical(pm$attraction$temperature$fixed)
    } else {
      similarity <- .jnull("org/ddahl/shallot/parameter/Similarity")
      permutation <- .jnull("org/ddahl/shallot/parameter/Permutation")
      permutationFixed <- TRUE
      temperature <- 0.0
      temperatureShape <- 0.0
      temperatureRate <- 0.0
      temperatureFixed <- TRUE
    }
    if ( is.null(mcmc.parameters) ) {
      sampler <- .jcall(interface,"Lscala/Function2;","makeForwardSamplerForR",
        distribution.name,as.integer(pm$n.items),similarity,
        mass,massShape,massRate,massFixed,
        discount,discountShape1,discountShape2,discountFixed,
        permutation,permutationFixed,
        temperature,temperatureShape,temperatureRate,temperatureFixed)
      augmentedSamples <- NULL
      samples <- .jcall(interface,"Lscala/collection/immutable/List;","sampleForward",as.integer(n.draws),rdg,sampler,as.logical(parallel))
    } else {
      sampling.model <- if ( is.null(mcmc.parameters$sampling.model) ) .jnull("org/ddahl/shallot/r/RAdapter")
      else mcmc.parameters$sampling.model
      sampler <- .jcall(interface,'Lorg/ddahl/shallot/r/RInterface$MCMCSampler;',"makeMCMCSamplerForR",
        distribution.name,as.integer(pm$n.items),similarity,
        mass,massShape,massRate,massFixed,mcmc.parameters$mass.rw.sd,
        discount,discountShape1,discountShape2,discountFixed,mcmc.parameters$discount.rw.sd,
        permutation,permutationFixed,as.integer(min(mcmc.parameters$permutation.grab.size,pm$n.items)),
        temperature,temperatureShape,temperatureRate,temperatureFixed,mcmc.parameters$temperature.rw.sd,
        sampling.model)
      augmentedSamples <- .jcall(interface,"Lscala/collection/immutable/List;","sampleMCMC",as.integer(n.draws),mcmc.parameters$n.iterations.per.sample,rdg,sampler)
      samples <- .jcall(interface,"Lscala/collection/immutable/List;","extractSamples",augmentedSamples)
    }
    result <- list(proc.time=proc.time()-start.time,n.items=pm$n.items,mcmc.parameters=mcmc.parameters,jobjRef=list(interface=interface,rdg=rdg,samples=samples,sampler=sampler,augmentedSamples=augmentedSamples))
  } else if ( class(x) == "shallot.samples" ) {
    if ( ! is.null(mcmc.parameters) ) stop("mcmc.parameters must be null when continuing.")
    if ( ! is.null(seed) ) stop("seed must be null when continuing.")
    if ( is.null(x$mcmc.parameters) ) {
      augmentedSamples <- NULL
      samples <- .jcall(x$jobjRef$interface,"Lscala/collection/immutable/List;","sampleForward",as.integer(n.draws),x$jobjRef$rdg,x$jobjRef$sampler,as.logical(parallel))
      samples <- .jcall(x$jobjRef$interface,"Lscala/collection/immutable/List;","mergeSamples",samples,x$jobjRef$samples)
    } else {
      augmentedSamples <- .jcall(x$jobjRef$interface,"Lscala/collection/immutable/List;","sampleMCMC",as.integer(n.draws),x$mcmc.parameters$n.iterations.per.sample,x$jobjRef$rdg,x$jobjRef$sampler)
      samples <- .jcall(x$jobjRef$interface,"Lscala/collection/immutable/List;","extractSamples",augmentedSamples)
      samples <- .jcall(x$jobjRef$interface,"Lscala/collection/immutable/List;","mergeSamples",samples,x$jobjRef$samples)
      augmentedSamples <- .jcall(x$jobjRef$interface,"Lscala/collection/immutable/List;","mergeAugmentedSamples",augmentedSamples,x$jobjRef$augmentedSamples)
    }
    result <- list(proc.time=x$proc.time+(proc.time()-start.time),n.items=x$n.items,mcmc.parameters=x$mcmc.parameters,jobjRef=list(interface=x$jobjRef$interface,rdg=x$jobjRef$rdg,samples=samples,sampler=x$jobjRef$sampler,augmentedSamples=augmentedSamples))
  } else stop("First argument is not recognized.")
  class(result) <- "shallot.samples"
  result
}

process <- function(x, reset=FALSE, ...) {
  callBackEngine <- .jengine(start=TRUE)
  xx <- .jcall(x$jobjRef$interface,"Lscala/Tuple2;","partitionsForR",callBackEngine,x$jobjRef$samples)
  partitions <- .jevalArray(.jcall(xx,"Ljava/lang/Object;","_1"),simplify=TRUE)
  colnames(partitions) <- paste("c",1:x$n.items,sep="")
  n.subsets <- .jcall(x$jobjRef$interface,"[I","extractNSubsets",x$jobjRef$samples,simplify=TRUE)
  entropy <- .jcall(x$jobjRef$interface,"[D","extractEntropy",x$jobjRef$samples,simplify=TRUE)
  if ( ! is.null(x$jobjRef$augmentedSamples) ) {
    mass <- .jcall(x$jobjRef$interface,"[D","extractMasses",x$jobjRef$augmentedSamples,simplify=TRUE)
    discount <- .jcall(x$jobjRef$interface,"[D","extractDiscounts",x$jobjRef$augmentedSamples,simplify=TRUE)
    temperature <- .jcall(x$jobjRef$interface,"[D","extractTemperatures",x$jobjRef$augmentedSamples,simplify=TRUE)
    if ( ! is.null(x$mcmc.parameters) ) {
      if ( reset ) .jcall(x$jobjRef$sampler,"V","reset")
      rates <- .jcall(x$jobjRef$sampler,"[D","rates")
      names(rates) <- c("mass","discount","permutation","temperature")
      y <- lapply(.jevalArray(.jcall(xx,"Ljava/lang/Object;","_2")),function(y) .jevalArray(y))
      parameters <- lapply(y, function(z) lapply(z,function(w) eval(parse(text=w))))
      list(partitions=partitions,n.subsets=n.subsets,entropy=entropy,mass=mass,discount=discount,temperature=temperature,parameters=parameters,rates=rates)
    } else {
      list(partitions=partitions,n.subsets=n.subsets,entropy=entropy,mass=mass,discount=discount,temperature=temperature)
    }
  } else {
    list(partitions=partitions,n.subsets=n.subsets,entropy=entropy)
  }
}

print.shallot.samples <- function(x, ...) {
  cat("samples --- use the 'process' function to extract information\n")
}





# Pairwise Probabilities
pairwise.probabilities <- function(x,parallel=TRUE) {
  start.time <- proc.time()
  if ( class(x) != "shallot.samples" ) x <- shallot.matrixOfPartitonsToShallotSamples(x)
  jobjRef <- .jcall(.jnew("org/ddahl/shallot/parameter/partition/PairwiseProbability$"),"Lorg/ddahl/shallot/parameter/partition/PairwiseProbability;","apply",x$jobjRef$samples,as.logical(parallel))
  result <- list(n.items=.jcall(jobjRef,"I","nItems"),proc.time=proc.time()-start.time,jobjRef=jobjRef)
  class(result) <- "shallot.pairwiseProbability"
  result
}

print.shallot.pairwiseProbability <- function(x, ...) {
  cat("pairwise probabilities for ",x$n.items," items --- use as.matrix function to obtain matrix\n",sep="")
}

as.matrix.shallot.pairwiseProbability <- function(x, ...) {
  .jcall(x$jobjRef,"[[D","toArray",simplify=TRUE)
}





# Estimate partition
estimate.partition <- function(samples, pairwise.probabilities=NULL, max.subsets=0, max.scans=0, parallel=TRUE) {
  start.time <- proc.time()
  if ( class(samples) != "shallot.samples" ) samples <- shallot.matrixOfPartitonsToShallotSamples(samples)
  if ( is.null(pairwise.probabilities) ) {
    pairwise.probabilities <- pairwise.probabilities(samples)
  } else if ( class(pairwise.probabilities) != "shallot.pairwiseProbability" ) {
    jobjRef <- .jcall(.jnew("org/ddahl/shallot/parameter/partition/PairwiseProbability$"),"Lorg/ddahl/shallot/parameter/partition/PairwiseProbability;","apply",.jarray(pairwise.probabilities,dispatch=TRUE))
    result <- list(n.items=.jcall(jobjRef,"I","nItems"),jobjRef=jobjRef)
    class(result) <- "shallot.pairwiseProbability"
    pairwise.probabilities <- result
  }
  jobjRef <- .jcall(.jnew("org/ddahl/shallot/parameter/partition/MinBinder$"),"Lorg/ddahl/shallot/parameter/partition/Partition;","apply",pairwise.probabilities$jobjRef,samples$jobjRef$samples,as.integer(max.subsets),as.integer(max.scans),as.logical(parallel))
  partition <- .jcall(jobjRef,"[I","toLabels")
  result <- list(partition=partition,n.items=.jcall(jobjRef,"I","nItems"),proc.time=proc.time()-start.time,jobjRef=jobjRef)
  class(result) <- "shallot.partition"
  result
}

print.shallot.partition <- function(x, ...) {
  print(x$partition)
}






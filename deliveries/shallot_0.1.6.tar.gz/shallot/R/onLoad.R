.onLoad <- function(libname, pkgname) {
  .jpackage(pkgname, morePaths=findScalaJars(), lib.loc=libname)
}


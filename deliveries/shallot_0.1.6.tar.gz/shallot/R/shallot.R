##########################
#### Not exported
##########################

load4Development <- function() {
  #library(rJava)
  #library(jvmr)
  .jaddClassPath("../inst/java/commons-math3.jar")
  .jaddClassPath("../inst/java/shallot.jar")
}

msg <- function(x,fmtstr="%Y-%m-%d %r") {
  cat(format(Sys.time(),fmtstr),": ",x,"\n",sep="")
}

clean <- function(full=FALSE) {
  what <- ls(all.names=TRUE,pattern="^.shallot\\..*",envir=.GlobalEnv)
  rm(list=what,envir=.GlobalEnv)
  if ( full ) {
    gc(FALSE)
    .jcall("java/lang/System","V","gc")
  }
}

stack.trace <- function(expr) {
  tryCatch(expr,Exception = function(e){
    print(e)
    cat(paste(unlist(lapply(.jevalArray(e$jobj$getStackTrace()),function(x) { x$toString() })),collapse="\n"),"\n",sep="")
  })  
}

matrixOfPartitionsToShallotSamples <- function(samples) {
  interface <- .jnew("org.ddahl.shallot.r.RInterface$")
  samples <- .jcall(interface,"Lscala/collection/immutable/List;","matrixToPartitions",.jarray(samples,dispatch=TRUE))
  names <- if ( is.null(colnames(samples)) ) paste("c",1:ncol(samples),sep="")
  else colnames(samples)
  result <- list(jobjRef=list(interface=interface,samples=samples,names=names))
  class(result) <- "shallot.samples.raw"
  samples <- result
}

labels2partition <- function(x) {
  if ( class(x) != "jobjRef" ) x <- .jcall(.jnew("org.ddahl.shallot.r.RInterface$"),"Lorg/ddahl/shallot/parameter/partition/Partition;","partition",as.integer(x))
  x
}

partition2labels <- function(x,names) {
  p <- as.integer(.jcall(x,"[I","toLabels") + 1)
  names(p) <- names
  p
}





##########################
#### Exported
##########################

# Adjusted Rand Index
adj.rand.index <- function(c1,c2) {
  n <- length(c1)
  if ( length(c2) != n ) stop("Clustering must be the same length.")
  t1  <- table(c1)
  t2  <- table(c2)
  t12 <- table(c1,c2)
  expected <- sum(choose(t1,2)) * sum(choose(t2,2)) / choose(n,2)
  numerator <- sum(choose(t12,2)) - expected
  denominator <- 0.5*(sum(choose(t1,2))+sum(choose(t2,2))) - expected
  numerator / denominator
}





# Mass
mass <- function(...,fixed=TRUE) {
  x <- c(...)
  value <- 1.2
  shape <- 2.5
  rate <- 2
  if ( length(x) == 0 ) {
  } else if ( length(x) == 1 ) {
    value <- as.double(x[1])
  } else if ( length(x) == 2 ) {
    if ( fixed ) stop("'fixed' should be FALSE if distribution parameters are specified.")
    shape <- as.double(x[1])
    rate <- as.double(x[2])
  } else stop("Incorrect number of arguments.")
  jobjRef <- .jcall("org.ddahl.shallot.parameter.Mass","Lorg/ddahl/shallot/parameter/Mass;","apply",as.double(value))
  factoryJobjRef <- if ( fixed ) {
    .jcall("org.ddahl.shallot.parameter.Mass","Lscala/Function0;","factory",as.double(value))
  } else {
    .jcall("org.ddahl.shallot.parameter.Mass","Lscala/Function0;","factory",as.double(shape),as.double(rate),.jnew("org/apache/commons/math3/random/RandomDataGenerator"))
  }
  result <- list(value=value,shape=shape,rate=rate,fixed=fixed,jobjRef=jobjRef,factoryJobjRef=factoryJobjRef)
  class(result) <- "shallot.mass"
  result
}

print.shallot.mass <- function(x, ...) {
  if ( x$fixed ) cat("mass fixed at ",x$value,"\n",sep="")
  else cat("mass sampled from Gamma(shape=",x$shape,",rate=",x$rate,")\n",sep="")
}





# Discount
discount <- function(...,fixed=TRUE) {
  x <- c(...)
  value <- 0.05
  shape1 <- 1
  shape2 <- 1
  if ( length(x) == 0 ) {
  } else if ( length(x) == 1 ) {
    value <- as.double(x[1])
  } else if ( length(x) == 2 ) {
    if ( fixed ) stop("'fixed' should be FALSE if distribution parameters are specified.")
    shape1 <- as.double(x[1])
    shape2 <- as.double(x[2])
  } else stop("Incorrect number of arguments.")
  jobjRef <- .jcall("org.ddahl.shallot.parameter.Discount","Lorg/ddahl/shallot/parameter/Discount;","apply",as.double(value))
  factoryJobjRef <- if ( fixed ) {
    .jcall("org.ddahl.shallot.parameter.Discount","Lscala/Function0;","factory",as.double(value))
  } else {
    .jcall("org.ddahl.shallot.parameter.Discount","Lscala/Function0;","factory",as.double(shape1),as.double(shape2),.jnew("org/apache/commons/math3/random/RandomDataGenerator"))
  }
  result <- list(value=value,shape1=shape1,shape2=shape2,fixed=fixed,jobjRef=jobjRef,factoryJobjRef=factoryJobjRef)
  class(result) <- "shallot.discount"
  result
}

print.shallot.discount <- function(x, ...) {
  if ( x$fixed ) cat("discount fixed at ",x$value,"\n",sep="")
  else cat("discount sampled from Beta(shape1=",x$shape1,",shape2=",x$shape2,")\n",sep="")
}





# Distance
distance <- function(x,multiplier=0.01) {
  distanceCO <- .jnew("org.ddahl.shallot.parameter.Distance$")
  xx <- as.matrix(x)
  if ( min(xx[lower.tri(xx)]) <= 0 ) xx <- xx + multiplier*min(xx[xx>0])
  names <- if ( is.null(colnames(xx)) ) {
    paste("c",1:ncol(xx),sep="")
  } else {
    colnames(xx)
  }
  y <- .jarray(xx,dispatch=TRUE)
  jobjRef <- .jcall(distanceCO,"Lorg/ddahl/shallot/parameter/Distance;","apply",y,FALSE)
  result <- list(n.items=.jcall(jobjRef,"I","nItems"),names=names,jobjRef=jobjRef)
  class(result) <- "shallot.distance"
  result
}

print.shallot.distance <- function(x, ...) {
  cat("distance for ",x$n.items," items\n",sep="")
}

as.matrix.shallot.distance <- function(x, ...) {
  y <- .jcall(x$jobjRef,"[[D","toArray",simplify=TRUE)
  dimnames(y) <- list(x$names,x$names)
  y
}





# Permutation
permutation <- function(...,n.items=NULL,fixed=TRUE) {
  x <- c(...) - 1
  permutationCO <- .jnew("org.ddahl.shallot.parameter.Permutation$")
  if ( length(x) == 0 ) {
    if ( is.null(n.items) ) stop("'n.items' must be specified if permutation is not given.")
    if ( fixed ) stop("'fixed' must be FALSE if permutation is not given.")
    jobjRef <- .jcall(permutationCO,"Lorg/ddahl/shallot/parameter/Permutation;","apply",as.integer(seq(n.items)-1))
  } else {
    if ( is.null(n.items) ) n.items <- length(x)
    if ( n.items != length(x) ) stop("'n.items' is not equal to the length of the permutation.")
    jobjRef <- .jcall(permutationCO,"Lorg/ddahl/shallot/parameter/Permutation;","apply",as.integer(x))
  }
  result <- list(n.items=n.items,fixed=fixed,jobjRef=jobjRef)
  class(result) <- "shallot.permutation"
  result
}

print.shallot.permutation <- function(x, ...) {
  if ( x$fixed ) {
    y <- .jcall(x$jobjRef,"S","toString")
    width <- 50
    if ( nchar(y) > width ) y <- paste(strtrim(y,width-3),"...",sep="")
    cat("permutation of ",x$n.items," items fixed at ",y,"\n",sep="")
  }
  else cat("permutation of ",x$n.items," items sampled uniformly\n",sep="")
}




# Temperature
temperature <- function(...,fixed=TRUE) {
  x <- c(...)
  value <- 3
  shape <- 2
  rate <- 0.5
  if ( length(x) == 0 ) {
  } else if ( length(x) == 1 ) {
    if ( ! fixed ) stop("'fixed' should be TRUE if value is specified.")
    value <- as.double(x[1])
  } else if ( length(x) == 2 ) {
    if ( fixed ) stop("'fixed' should be FALSE if distribution parameters are specified.")
    shape <- as.double(x[1])
    rate <- as.double(x[2])
  } else stop("Incorrect number of arguments.")
  result <- list(value=value,shape=shape,rate=rate,fixed=fixed)
  class(result) <- "shallot.temperature"
  result
}

print.shallot.temperature <- function(x, ...) {
  if ( x$fixed ) cat("temperature fixed at ",x$value,"\n",sep="")
  else cat("temperature sampled from Gamma(shape=",x$shape,",rate=",x$rate,")\n",sep="")
}




# Decay functions
decay.reciprocal <- function(...,fixed=TRUE) decay.generic(...,type="reciprocal",multiplier=1.01,fixed=fixed)
decay.exponential <- function(...,fixed=TRUE) decay.generic(...,type="exponential",multiplier=1.01,fixed=fixed)
decay.subtraction <- function(...,multiplier=1.01,fixed=TRUE) decay.generic(...,multiplier=multiplier,type="subtraction",fixed=fixed)

decay.generic <- function(...,multiplier,type,fixed) {
  result <- list(type=type,multiplier=multiplier,temperature=temperature(...,fixed=fixed))
  class(result) <- "shallot.decay"
  result
}

print.shallot.decay <- function(x, ...) {
  cat(x$type,"decay function with ")
  if ( x$temperature$fixed ) cat("temperature fixed at ",x$temperature$value,"\n",sep="")
  else cat("temperature sampled from Gamma(shape=",x$temperature$shape,",rate=",x$temperature$rate,")\n",sep="")
}












# Attraction
attraction <- function(distance, permutation, decay) {
  fixed <- permutation$fixed && decay$temperature$fixed
  jobjRef <- if ( fixed ) {
    decayJobjRef <- if ( decay$type == "reciprocal" ) {
      .jcall("org.ddahl.shallot.parameter.decay.ReciprocalDecayFactory","Lorg/ddahl/shallot/parameter/decay/ReciprocalDecay;","apply",as.numeric(decay$temperature$value))
    } else if ( decay$type == "exponential" ) {
      .jcall("org.ddahl.shallot.parameter.decay.ExponentialDecayFactory","Lorg/ddahl/shallot/parameter/decay/ExponentialDecay;","apply",as.numeric(decay$temperature$value))
    } else if ( decay$type == "subtraction" ) {
      tmpObj <- .jcall(.jnew("org.ddahl.shallot.parameter.decay.SubtractionDecayFactory$"),"Lorg/ddahl/shallot/parameter/decay/SubtractionDecayFactory;","apply",as.double(decay$multiplier*.jcall(distance$jobjRef,"D","max")))
      .jcall(tmpObj,"Lorg/ddahl/shallot/parameter/decay/SubtractionDecay;","apply",as.double(decay$temperature$value))
    } else stop("Unrecognized decay function.")
    p <- permutation$jobjRef
    attractionCO <- .jnew("org.ddahl.shallot.distribution.Attraction$")
    .jcall(attractionCO,"Lorg/ddahl/shallot/distribution/Attraction;","apply",distance$jobjRef,permutation$jobjRef,.jcast(decayJobjRef,"org/ddahl/shallot/parameter/decay/DecayFunction"))
  } else NULL
  result <- list(n.items=distance$n.items, distance=distance, permutation=permutation, decay=decay, fixed=fixed, names=distance$names, jobjRef=jobjRef)
  class(result) <- "shallot.attraction"
  result
}

print.shallot.attraction <- function(x, ...) {
  cat("attraction for ",x$n.items," items:\n",sep="")
  cat("  ")
  print(x$distance)
  cat("  ")
  print(x$permutation)
  cat("  ")
  print(x$decay)
}

as.matrix.shallot.attraction <- function(x, ...) {
  y <- .jcall(x$jobjRef,"[[D","toArray",simplify=TRUE)
  dimnames(y) <- list(x$names,x$names)
  y
}





# Ewens
ewens <- function(mass, n.items, names=paste("c",1:n.items,sep="")) {
  result <- list(mass=mass,n.items=n.items,names=names)
  class(result) <- c("shallot.distribution","ewens")
  result
}

print.shallot.distribution.ewens <- function(x, ...) {
  cat("Ewens distribution with:\n")
  cat("  ",x$n.items," items\n",sep="")
  cat("  ")
  print(x$mass)
}





# Ewens Pitman
ewens.pitman <- function(mass, discount, n.items, names=paste("c",1:n.items,sep="")) {
  result <- list(mass=mass,discount=discount,n.items=n.items,names=names)
  class(result) <- c("shallot.distribution","ewensPitman")
  result
}

print.shallot.distribution.ewensPitman <- function(x, ...) {
  cat("Ewens Pitman distribution with:\n")
  cat("  ",x$n.items," items\n",sep="")
  cat("  ")
  print(x$mass)
  cat("  ")
  print(x$discount)
}





# Ewens Attraction
ewens.attraction <- function(mass, attraction) {
  result <- list(mass=mass,attraction=attraction,n.items=attraction$n.items,names=attraction$names)
  class(result) <- c("shallot.distribution","ewensAttraction")
  result
}

print.shallot.distribution.ewensAttraction <- function(x, ...) {
  cat("Ewens Attraction distribution with:\n")
  cat("  ")
  print(x$mass)
  x <- capture.output(print(x$attraction))
  cat(paste("  ",x,"\n",sep=""))
}





# Ewens Pitman Attraction
ewens.pitman.attraction <- function(mass, discount, attraction) {
  result <- list(mass=mass,discount=discount,attraction=attraction,n.items=attraction$n.items,names=attraction$names)
  class(result) <- c("shallot.distribution","ewensPitmanAttraction")
  result
}

print.shallot.distribution.ewensPitmanAttraction <- function(x, ...) {
  cat("Ewens Pitman Attraction distribution with:\n")
  cat("  ")
  print(x$mass)
  cat("  ")
  print(x$discount)
  x <- capture.output(print(x$attraction))
  cat(paste("  ",x,"\n",sep=""))
}





# Ewens Pitman Attraction Quantile
ewens.pitman.attraction.quantile <- function(mass, discount, attraction, p, timesSize) {
  result <- list(mass=mass,discount=discount,attraction=attraction,p=p,timesSize=timesSize,n.items=attraction$n.items,names=attraction$names)
  class(result) <- c("shallot.distribution","ewensPitmanAttractionQuantile")
  result
}

print.shallot.distribution.ewensPitmanAttractionQuantile <- function(x, ...) {
  cat("Ewens Pitman Attraction Quantile distribution with:\n")
  cat("  ")
  print(x$mass)
  cat("  ")
  print(x$discount)
  cat("  ")
  print(x$p)
  x <- capture.output(print(x$attraction))
  cat(paste("  ",x,"\n",sep=""))
}





# Distance dependent Chinese restaurant process
ddcrp <- function(mass, attraction) {
  result <- list(mass=mass,attraction=attraction,n.items=attraction$n.items,names=attraction$names)
  class(result) <- c("shallot.distribution","ddcrp")
  result
}

print.shallot.distribution.ddcrp <- function(x, ...) {
  cat("DDCRP distribution with:\n")
  cat("  ")
  print(x$mass)
  x <- capture.output(print(x$attraction))
  cat(paste("  ",x,"\n",sep=""))
}





# Distribution of the number of subsets
random.q <- function(x,n.samples) {
  if ( all(class(x) == c("shallot.distribution","ewens")) ) {
    .jcall("org.ddahl.shallot.distribution.Ewens","[I","sampleNumberOfSubsets",as.integer(x$n.items),x$mass$factoryJobjRef,as.integer(n.samples))
  } else if ( all(class(x) == c("shallot.distribution","ewensAttraction")) ) {
    .jcall("org.ddahl.shallot.distribution.EwensAttraction","[I","sampleNumberOfSubsets",as.integer(x$n.items),x$mass$factoryJobjRef,as.integer(n.samples))
  } else if (  all(class(x) == c("shallot.distribution","ewensPitman")) ) {
    .jcall("org.ddahl.shallot.distribution.EwensPitman","[I","sampleNumberOfSubsets",as.integer(x$n.items),x$mass$factoryJobjRef,x$discount$factoryJobjRef,as.integer(n.samples))
  } else if (  all(class(x) == c("shallot.distribution","ewensPitmanAttraction")) ) {
    .jcall("org.ddahl.shallot.distribution.EwensPitmanAttraction","[I","sampleNumberOfSubsets",as.integer(x$n.items),x$mass$factoryJobjRef,x$discount$factoryJobjRef,as.integer(n.samples))
  } else if (  all(class(x) == c("shallot.distribution","ewensPitmanAttractionQuantile")) ) {
    .jcall("org.ddahl.shallot.distribution.EwensPitmanAttractionQuantile","[I","sampleNumberOfSubsets",as.integer(x$n.items),x$mass$factoryJobjRef,x$discount$factoryJobjRef,as.integer(n.samples))
  } else stop("Unrecognized distribution.")
}

probability.q <- function(x,n.subsets) {
  if ( ! x$mass$fixed ) stop("'mass' must be fixed, but emperical estimates are available through random.q function.")
  if ( all(class(x) == c("shallot.distribution","ewens")) ) {
    .jcall("org.ddahl.shallot.distribution.Ewens","D","probabilityNumberOfSubsets",as.integer(x$n.items),as.integer(n.subsets),x$mass$jobjRef)
  } else if ( all(class(x) == c("shallot.distribution","ewensAttraction")) ) {
    .jcall("org.ddahl.shallot.distribution.EwensAttraction","D","probabilityNumberOfSubsets",as.integer(x$n.items),as.integer(n.subsets),x$mass$jobjRef)
  } else {
    if ( ! x$discount$fixed ) stop("'discount' must be fixed, but emperical estimates are available through random.q function.")
    if (  all(class(x) == c("shallot.distribution","ewensPitman")) ) {
      .jcall("org.ddahl.shallot.distribution.EwensPitman","D","probabilityNumberOfSubsets",as.integer(x$n.items),as.integer(n.subsets),x$mass$jobjRef,x$discount$jobjRef)
    } else if (  all(class(x) == c("shallot.distribution","ewensPitmanAttraction")) ) {
      .jcall("org.ddahl.shallot.distribution.EwensPitmanAttraction","D","probabilityNumberOfSubsets",as.integer(x$n.items),as.integer(n.subsets),x$mass$jobjRef,x$discount$jobjRef)
    } else if (  all(class(x) == c("shallot.distribution","ewensPitmanAttractionQuantile")) ) {
      .jcall("org.ddahl.shallot.distribution.EwensPitmanAttractionQuantile","D","probabilityNumberOfSubsets",as.integer(x$n.items),as.integer(n.subsets),x$mass$jobjRef,x$discount$jobjRef)
    } else stop("Unrecognized distribution.")
  }
}

mean.q <- function(x,...) {
  if ( ! x$mass$fixed ) stop("'mass' must be fixed, but emperical estimates are available through random.q function.")
  if ( all(class(x) == c("shallot.distribution","ewens")) ) {
    .jcall("org.ddahl.shallot.distribution.Ewens","D","meanNumberOfSubsets",as.integer(x$n.items),x$mass$jobjRef)
  } else if ( all(class(x) == c("shallot.distribution","ewensAttraction")) ) {
    .jcall("org.ddahl.shallot.distribution.EwensAttraction","D","meanNumberOfSubsets",as.integer(x$n.items),x$mass$jobjRef)
  } else {
    if ( ! x$discount$fixed ) stop("'discount' must be fixed, but emperical estimates are available through random.q function.")
    if (  all(class(x) == c("shallot.distribution","ewensPitman")) ) {
      .jcall("org.ddahl.shallot.distribution.EwensPitman","D","meanNumberOfSubsets",as.integer(x$n.items),x$mass$jobjRef,x$discount$jobjRef)
    } else if (  all(class(x) == c("shallot.distribution","ewensPitmanAttraction")) ) {
      .jcall("org.ddahl.shallot.distribution.EwensPitmanAttraction","D","meanNumberOfSubsets",as.integer(x$n.items),x$mass$jobjRef,x$discount$jobjRef)
    } else if (  all(class(x) == c("shallot.distribution","ewensPitmanAttractionQuantile")) ) {
      .jcall("org.ddahl.shallot.distribution.EwensPitmanAttractionQuantile","D","meanNumberOfSubsets",as.integer(x$n.items),x$mass$jobjRef,x$discount$jobjRef)
    } else stop("Unrecognized distribution.")
  }
}

variance.q <- function(x) {
  if ( ! x$mass$fixed ) stop("'mass' must be fixed, but emperical estimates are available through random.q function.")
  if ( all(class(x) == c("shallot.distribution","ewens")) ) {
    .jcall("org.ddahl.shallot.distribution.Ewens","D","varianceNumberOfSubsets",as.integer(x$n.items),x$mass$jobjRef)
  } else if ( all(class(x) == c("shallot.distribution","ewensAttraction")) ) {
    .jcall("org.ddahl.shallot.distribution.EwensAttraction","D","varianceNumberOfSubsets",as.integer(x$n.items),x$mass$jobjRef)
  } else {
    if ( ! x$discount$fixed ) stop("'discount' must be fixed, but emperical estimates are available through random.q function.")
    if (  all(class(x) == c("shallot.distribution","ewensPitman")) ) {
      stop("Unsupported distribution, but emperical estimates are available through random.q function.")
    } else if (  all(class(x) == c("shallot.distribution","ewensPitmanAttraction")) ) {
      stop("Unsupported distribution, but emperical estimates are available through random.q function.")
    } else if (  all(class(x) == c("shallot.distribution","ewensPitmanAttractionQuantile")) ) {
      stop("Unsupported distribution, but emperical estimates are available through random.q function.")
    } else stop("Unrecognized distribution.")
  }
}







# MCMC tuning
mcmc.parameters <- function(log.density.NAME=NULL,sample.NAME=NULL,mass.rw.sd=0.5,discount.rw.sd=0.1,permutation.grab.size=10,temperature.rw.sd=0.5,n.iterations.per.sample=1) {
  usesPredictiveDensity <- FALSE
  sampling.model <- if ( is.null(log.density.NAME) ) NULL
  else {
    callBackEngine <- .jengine(start=TRUE)
    if ( is.null(sample.NAME) ) {
      usesPredictiveDensity <- TRUE
      sample.NAME <- ""
    }
    .jcall("org/ddahl/shallot/r/RAdapter","Lorg/ddahl/shallot/r/RAdapter;","apply",callBackEngine,as.logical(usesPredictiveDensity),log.density.NAME,sample.NAME)
  }
  result <- list(
    mass.rw.sd=as.double(mass.rw.sd),
    discount.rw.sd=as.double(discount.rw.sd),
    permutation.grab.size=as.integer(permutation.grab.size),
    temperature.rw.sd=as.double(temperature.rw.sd),
    n.iterations.per.sample=as.integer(n.iterations.per.sample),
    uses.predictive.density=as.logical(usesPredictiveDensity),
    sampling.model=sampling.model)
  class(result) <- "shallot.mcmc.parameters"
  result
}





# collect
collect <- function(x,n.draws=1000,mcmc.parameters=NULL,parallel=TRUE,seed=NULL,reset=FALSE) {
  start.time <- proc.time()
  if ( n.draws < 1 ) stop("n.draws must be at least 1.")
  if ( inherits(x,"shallot.distribution") ) {
    interface <- .jnew("org.ddahl.shallot.r.RInterface$")
    pm <- x
    rdg <- .jnew("org/apache/commons/math3/random/RandomDataGenerator")
    if ( ! is.null(seed) ) rdg$reSeed(.jlong(seed))
    distribution.name <- paste(class(pm),collapse=".")
    mass <- as.double(pm$mass$value)
    massShape <- as.double(pm$mass$shape)
    massRate <- as.double(pm$mass$rate)
    massFixed <- as.logical(pm$mass$fixed)
    if ( distribution.name %in% c("shallot.distribution.ewensPitman","shallot.distribution.ewensPitmanAttraction","shallot.distribution.ewensPitmanAttractionQuantile") ) {
      discount <- as.double(pm$discount$value)
      discountShape1 <- as.double(pm$discount$shape1)
      discountShape2 <- as.double(pm$discount$shape2)
      discountFixed <- as.logical(pm$discount$fixed)
    } else {
      discount <- 0.0
      discountShape1 <- 0.0
      discountShape2 <- 0.0
      discountFixed <- TRUE
    }
    if ( distribution.name %in% c("shallot.distribution.ewensAttraction","shallot.distribution.ewensPitmanAttraction","shallot.distribution.ewensPitmanAttractionQuantile","shallot.distribution.ddcrp") ) {
      distance <- pm$attraction$distance$jobjRef
      permutation <- pm$attraction$permutation$jobjRef
      permutationFixed <- as.logical(pm$attraction$permutation$fixed)
      decayString <- as.character(pm$attraction$decay$type)
      decayMultiplier <- as.double(pm$attraction$decay$multiplier)
      temperature <- as.double(pm$attraction$decay$temperature$value)
      temperatureShape <- as.double(pm$attraction$decay$temperature$shape)
      temperatureRate <- as.double(pm$attraction$decay$temperature$rate)
      temperatureFixed <- as.logical(pm$attraction$decay$temperature$fixed)
    } else {
      distance <- .jnull("org/ddahl/shallot/parameter/Distance")
      permutation <- .jnull("org/ddahl/shallot/parameter/Permutation")
      permutationFixed <- TRUE
      decayString <- ""
      decayMultiplier <- 1.0
      temperature <- 0.0
      temperatureShape <- 0.0
      temperatureRate <- 0.0
      temperatureFixed <- TRUE
    }
    if ( distribution.name == "shallot.distribution.ewensPitmanAttractionQuantile" ) {
      p <- as.double(pm$p)
      timesSize <- as.logical(pm$timesSize)
    } else {
      p <- 2.0
      timesSize <- TRUE
    }
    if ( is.null(mcmc.parameters) ) {
      sampler <- .jcall(interface,"Lscala/Function2;","makeForwardSamplerForR",
        distribution.name,as.integer(pm$n.items),distance,
        mass,massShape,massRate,massFixed,
        discount,discountShape1,discountShape2,discountFixed,
        permutation,permutationFixed,
        decayString,decayMultiplier,
        temperature,temperatureShape,temperatureRate,temperatureFixed,p,timesSize)
      augmentedSamples <- NULL
      samples <- .jcall(interface,"Lscala/collection/immutable/List;","sampleForward",as.integer(n.draws),rdg,sampler,as.logical(parallel))
    } else {
      print("testing")
      sampling.model <- if ( is.null(mcmc.parameters$sampling.model) ) .jnull("org/ddahl/shallot/r/RAdapter")
      else mcmc.parameters$sampling.model
      sampler <- .jcall(interface,'Lorg/ddahl/shallot/r/RInterface$MCMCSampler;',"makeMCMCSamplerForR",
        distribution.name,as.integer(pm$n.items),distance,
        mass,massShape,massRate,massFixed,mcmc.parameters$mass.rw.sd,
        discount,discountShape1,discountShape2,discountFixed,mcmc.parameters$discount.rw.sd,
        permutation,permutationFixed,as.integer(min(mcmc.parameters$permutation.grab.size,pm$n.items)),
        decayString,decayMultiplier,
        temperature,temperatureShape,temperatureRate,temperatureFixed,mcmc.parameters$temperature.rw.sd,
        sampling.model)
      augmentedSamples <- .jcall(interface,"Lscala/collection/immutable/List;","sampleMCMC",as.integer(n.draws),mcmc.parameters$n.iterations.per.sample,rdg,sampler)
      samples <- .jcall(interface,"Lscala/collection/immutable/List;","extractSamples",augmentedSamples)
      suppressWarnings(rm(list=c(".shallot.S.tmp",".shallot.P.tmp"),envir=.GlobalEnv))
    }
    n.samples <- .jcall(samples,"I","length")
    result <- list(proc.time=proc.time()-start.time,n.items=pm$n.items,n.samples=n.samples,names=x$names,mcmc.parameters=mcmc.parameters,jobjRef=list(interface=interface,rdg=rdg,samples=samples,sampler=sampler,augmentedSamples=augmentedSamples))
  } else if ( class(x) == "shallot.samples.raw" ) {
    if ( ! is.null(mcmc.parameters) ) stop("mcmc.parameters must be null when continuing.")
    if ( ! is.null(seed) ) stop("seed must be null when continuing.")
    if ( is.null(x$mcmc.parameters) ) {
      augmentedSamples <- NULL
      if ( reset ) {
        samples <- .jcall(x$jobjRef$samples,"Lscala/collection/immutable/List;","take",as.integer(1))
      } else {
        samples <- .jcall(x$jobjRef$interface,"Lscala/collection/immutable/List;","sampleForward",as.integer(n.draws),x$jobjRef$rdg,x$jobjRef$sampler,as.logical(parallel))
        samples <- .jcall(x$jobjRef$interface,"Lscala/collection/immutable/List;","mergeSamples",samples,x$jobjRef$samples)
      }
    } else {
      if ( reset ) {
        augmentedSamples <- .jcall(x$jobjRef$augmentedSamples,"Lscala/collection/immutable/List;","take",as.integer(1))
        samples <- .jcall(x$jobjRef$samples,"Lscala/collection/immutable/List;","take",as.integer(1))
      } else {
        augmentedSamples <- .jcall(x$jobjRef$interface,"Lscala/collection/immutable/List;","sampleMCMC",as.integer(n.draws),x$mcmc.parameters$n.iterations.per.sample,x$jobjRef$rdg,x$jobjRef$sampler)
        samples <- .jcall(x$jobjRef$interface,"Lscala/collection/immutable/List;","extractSamples",augmentedSamples)
        samples <- .jcall(x$jobjRef$interface,"Lscala/collection/immutable/List;","mergeSamples",samples,x$jobjRef$samples)
        augmentedSamples <- .jcall(x$jobjRef$interface,"Lscala/collection/immutable/List;","mergeAugmentedSamples",augmentedSamples,x$jobjRef$augmentedSamples)
        suppressWarnings(rm(list=c(".shallot.S.tmp",".shallot.P.tmp"),envir=.GlobalEnv))
      }
    }
    if ( reset ) .jcall(x$jobjRef$sampler,"V","reset")
    n.samples <- .jcall(samples,"I","length")
    result <- list(proc.time=x$proc.time+(proc.time()-start.time),n.items=x$n.items,n.samples=n.samples,names=x$names,mcmc.parameters=x$mcmc.parameters,jobjRef=list(interface=x$jobjRef$interface,rdg=x$jobjRef$rdg,samples=samples,sampler=x$jobjRef$sampler,augmentedSamples=augmentedSamples))
  } else stop("First argument is not recognized.")
  class(result) <- "shallot.samples.raw"
  result
}

print.shallot.samples.raw <- function(x, ...) {
  cat("raw samples --- use the 'process' function to extract information\n")
}





# Process
process <- function(x, ...) {
  start.time <- proc.time()
  callBackEngine <- .jengine(start=TRUE)
  withParameters <- ! is.null(x$jobjRef$augmentedSamples) && ! is.null(x$mcmc.parameters) && ! x$mcmc.parameters$uses.predictive.density
  samples <- .jcall(x$jobjRef$samples,"Lscala/collection/immutable/List;","reverse")
  xx <- .jcall(x$jobjRef$interface,"Lscala/Tuple2;","partitionsForR",callBackEngine,samples,withParameters)
  partitions <- .jevalArray(.jcall(xx,"Ljava/lang/Object;","_1"),simplify=TRUE)
  colnames(partitions) <- x$names
  n.subsets <- .jcall(x$jobjRef$interface,"[I","extractNSubsets",samples,simplify=TRUE)
  entropy <- .jcall(x$jobjRef$interface,"[D","extractEntropy",samples,simplify=TRUE)
  result <- list(partitions=partitions,n.subsets=n.subsets,entropy=entropy)
  if ( ! is.null(x$jobjRef$augmentedSamples) ) {
    recordMass <- .jcall(x$jobjRef$sampler,"Z","recordMass")
    recordDiscount <- .jcall(x$jobjRef$sampler,"Z","recordDiscount")
    recordPermutation <- .jcall(x$jobjRef$sampler,"Z","recordPermutation")
    recordTemperature <- .jcall(x$jobjRef$sampler,"Z","recordTemperature")
    augmentedSamples <- .jcall(x$jobjRef$augmentedSamples,"Lscala/collection/immutable/List;","reverse")
    if ( recordMass ) result <- c(result,list(mass=.jcall(x$jobjRef$interface,"[D","extractMasses",augmentedSamples,simplify=TRUE)))
    if ( recordDiscount ) result <- c(result,list(discount=.jcall(x$jobjRef$interface,"[D","extractDiscounts",augmentedSamples,simplify=TRUE)))
    if ( recordTemperature ) result <- c(result,list(temperature=.jcall(x$jobjRef$interface,"[D","extractTemperatures",augmentedSamples,simplify=TRUE)))
    if ( ! is.null(x$mcmc.parameters) ) {
      rates <- .jcall(x$jobjRef$sampler,"[D","rates")
      names(rates) <- c("mass","discount","permutation","temperature")
      rates <- rates[c(recordMass,recordDiscount,recordPermutation,recordTemperature)]
      y <- lapply(.jevalArray(.jcall(xx,"Ljava/lang/Object;","_2")),function(y) .jevalArray(y))
      parameters <- lapply(y, function(z) lapply(z,function(w) eval(parse(text=w))))
      rm(list=unlist(y),envir=.GlobalEnv)
      result <- c(result,list(parameters=parameters,rates=rates))
    }
  }
  result <- c(result,list(proc.time=proc.time()-start.time))
  class(result) <- "shallot.samples"
  result
}

print.shallot.samples <- function(x, ...) {
  cat("samples --- list with elements: ",paste(names(x),collapse=", "),".\n",sep="")
}





# Current state
current.state <- function(x) {
  callBackEngine <- .jengine(start=TRUE)
  withParameters <- ! is.null(x$jobjRef$augmentedSamples) && ! is.null(x$mcmc.parameters)
  xx <- .jcall(x$jobjRef$interface,"Lscala/Tuple2;","currentPartitionForR",callBackEngine,x$jobjRef$samples,withParameters)
  partition <- .jevalArray(.jcall(xx,"Ljava/lang/Object;","_1"),simplify=TRUE)
  names(partition) <- x$names
  if ( ! is.null(x$jobjRef$augmentedSamples) && ! is.null(x$mcmc.parameters) ) {
    y <- .jevalArray(.jcall(xx,"Ljava/lang/Object;","_2"))
    parameters <- lapply(y, function(w) eval(parse(text=w)))
    rm(list=y,envir=.GlobalEnv)
    result <- list(partition=partition,parameters=parameters)
  } else result <- list(partition=partition)
  class(result) <- "shallot.state"
  result
}

print.shallot.state <- function(x, ...) {
  cat("partition:\n")
  print(x$partition)
  if ( ! is.null(x$parameters) ) {
    cat("\n")
    cat("parameters:\n")
    print(x$parameters)
  }
}





# Pairwise Probabilities
pairwise.probabilities <- function(x,parallel=TRUE) {
  start.time <- proc.time()
  if ( class(x) != "shallot.samples.raw" ) x <- matrixOfPartitionsToShallotSamples(x)
  jobjRef <- .jcall(.jnew("org/ddahl/shallot/parameter/partition/PairwiseProbability$"),"Lorg/ddahl/shallot/parameter/partition/PairwiseProbability;","apply",x$jobjRef$samples,as.logical(parallel))
  result <- list(n.items=.jcall(jobjRef,"I","nItems"),names=x$names,proc.time=proc.time()-start.time,jobjRef=jobjRef)
  class(result) <- "shallot.pairwiseProbability"
  result
}

print.shallot.pairwiseProbability <- function(x, ...) {
  cat("pairwise probabilities for ",x$n.items," items --- use as.matrix function to obtain matrix\n",sep="")
}

as.matrix.shallot.pairwiseProbability <- function(x, ...) {
  y <- .jcall(x$jobjRef,"[[D","toArray",simplify=TRUE)
  z <- x$names
  dimnames(y) <- list(z,z)
  y
}





# Estimate partition
estimate.partition <- function(x, pairwise.probabilities=NULL, max.subsets=0, max.scans=0, parallel=TRUE) {
  start.time <- proc.time()
  if ( class(x) != "shallot.samples.raw" ) x <- matrixOfPartitionsToShallotSamples(x)
  if ( is.null(pairwise.probabilities) ) pairwise.probabilities <- pairwise.probabilities(x)
  jobjRef <- .jcall(.jnew("org/ddahl/shallot/parameter/partition/MinBinder$"),"Lorg/ddahl/shallot/parameter/partition/Partition;","apply",pairwise.probabilities$jobjRef,x$jobjRef$samples,as.integer(max.subsets),as.integer(max.scans),as.logical(parallel))
  p <- partition2labels(jobjRef,x$names)
  attr(p,"proc.time") <- proc.time() - start.time
  p
}





# Confidence
confidence <- function(pairwise.probabilities, partition) {
  tmpObj <- .jcall(pairwise.probabilities$jobjRef,"Lscala/Tuple5;","confidenceComputations",labels2partition(partition))
  partition <- .jevalArray(.jcall(tmpObj,"Ljava/lang/Object;","_1")) + 1
  names(partition) <- pairwise.probabilities$names
  confidence <- .jevalArray(.jcall(tmpObj,"Ljava/lang/Object;","_2"))
  names(confidence) <- names(partition)
  confidence.matrix <- .jevalArray(.jcall(tmpObj,"Ljava/lang/Object;","_3",evalArray=FALSE),simplify=TRUE)
  dimnames(confidence.matrix) <- list(1:nrow(confidence.matrix),1:ncol(confidence.matrix))
  order <- as.integer(.jevalArray(.jcall(tmpObj,"Ljava/lang/Object;","_4")) + 1)
  names(order) <- names(partition)
  exemplar <- as.integer(.jevalArray(.jcall(tmpObj,"Ljava/lang/Object;","_5")) + 1)
  names(exemplar) <- 1:length(exemplar)
  result <- list(partition=partition,confidence=confidence,confidence.matrix=confidence.matrix,exemplar=exemplar,order=order,pairwise.probabilities=pairwise.probabilities)
  class(result) <- "shallot.confidence"
  result
}





# Confidence or pairs plot
plot.shallot.confidence <- function(x, partition=NULL, data=NULL, show.labels=length(x$partition)<=50, ...) {
  if ( ! is.null(data) ) {
    if ( ! is.null(partition) ) stop("Clustering must be 'NULL' for pairs plot.")
    i <- x$exemplar[x$partition]
    c <- rainbow(length(x$exemplar))[x$partition]
    panelFnc <- function(x0,y0,...) {
      points(x0,y0,col=c,pch=19,...)
      segments(x0,y0,x0[i],y0[i],col=c,...)
      points(x0[x$exemplar],y0[x$exemplar],pch=22,bg="white",cex=2,...)
    }
    pairs(data,panel=panelFnc)
    return(invisible())
  }
  if ( is.null(partition) ) {
    partition <- x$partition
    o <- x$order
  } else {
    o <- order(partition)
  }
  interface <- .jnew("org.ddahl.shallot.r.RInterface$")
  pm <- .jevalArray(.jcall(interface,"[[D","rotateForConfidencePlot",x$pairwise.probabilities$jobjRef,o,evalArray=FALSE),simplify=TRUE)
  n <- nrow(pm)
  sizes <- rle(partition[o])$lengths
  cuts <- cumsum(sizes)
  centers <- ( c(0,cuts[-length(cuts)]) + cuts ) / 2
  cuts <- cuts[-length(cuts)]
  labels <- rle(partition[o])$values
  if ( show.labels ) {
    mymai <- c(1.5,0.5,0.5,1.5)
    cexscale <- 0.85 * 50 / length(partition)
  } else {
    mymai <- c(0,0,0,0)
    cexscale <- 1 * 50 / length(partition)
  }
  opar <- par(pty="s",mai=mymai)
  colors <- topo.colors(200)
  colors <- rev(heat.colors(200))
  image(x=1:n,y=1:n,z=pm,axes=FALSE,xlab="",ylab="",col=colors)
  box()
  abline(v=cuts+0.5,lwd=3)
  abline(h=n-cuts+0.5,lwd=3)
  text(centers+0.5,n-centers+0.5,labels,cex=0.8*cexscale*sizes)
  if ( show.labels ) {
    axisLabels <- if ( is.null(names(partition)) ) o
    else names(partition[o])
    axis(4,1:length(partition),rev(axisLabels),las=2,cex.axis=0.8*cexscale)
    axis(1,1:length(partition),axisLabels,las=2,cex.axis=0.8*cexscale)
    nn <- length(colors)
    bx <- par("usr")
    bx.cx <- c(bx[1] - 1.6 * (bx[2] - bx[1]) / 50, bx[1] - 0.3 * (bx[2] - bx[1]) / 50)
    bx.cy <- c(bx[3], bx[3])
    bx.sy <- (bx[4] - bx[3]) / nn
    xx <- rep(bx.cx, each=2)
    for ( i in 1:nn ) {
      yy <- c(bx.cy[1] + (bx.sy * (i - 1)),
              bx.cy[1] + (bx.sy * (i)),
              bx.cy[1] + (bx.sy * (i)),
              bx.cy[1] + (bx.sy * (i - 1)))
      polygon(xx,yy,col=colors[i],border=colors[i],xpd=TRUE)
    }
  }
  par(opar)
  invisible()
}






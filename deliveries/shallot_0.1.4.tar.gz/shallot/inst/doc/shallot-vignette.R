## ----setup, echo=FALSE---------------------------------------------------
library(knitr)
opts_chunk$set(comment=NA, size="footnotesize", fig.width=6, fig.height=6)

## ----install, eval=FALSE-------------------------------------------------
#  install.packages("jvmr")
#  install.packages("shallot_1.0.0.tar.gz",type="source")

## ----load----------------------------------------------------------------
library("shallot")

## ----data----------------------------------------------------------------
data <- c(a=-1.48, b=-1.40, c=-1.16, d=-1.08, e=-1.02, f=0.14, g=0.51, h=0.53, i=0.78)

## ----fixedparameters, tidy=FALSE-----------------------------------------
lambda  <- 0.1^-2
mu0     <- 0.0
lambda0 <- 1.0^-2

## ----logposteriorpredictive, tidy=FALSE----------------------------------
jainneal.log.predictive.density <- function(i,subset) {
  precision <- lambda0 + length(subset)*lambda
  mean <- (lambda0*mu0 + lambda*sum(data[subset]))/precision
  dnorm(data[i],mean=mean,
                sd=1/sqrt(lambda*precision/(precision+lambda)),
                log=TRUE)
}

## ----mcmcparamters1, tidy=FALSE------------------------------------------
mcmc.params <- mcmc.parameters(
  log.density.NAME="jainneal.log.predictive.density")

## ----ewens---------------------------------------------------------------
NDRAWS <- 1000
NDRAWS <- 10
dist <- ewens(mass(1.0,fixed=TRUE),length(data))

## ----collect-------------------------------------------------------------
mcmc <- collect(dist,n.draws=NDRAWS,mcmc.parameters=mcmc.params)

## ----collect1------------------------------------------------------------
mcmc <- collect(mcmc,n.draws=NDRAWS)

## ----process1------------------------------------------------------------
output <- process(mcmc)

## ----analysis1-----------------------------------------------------------
# See what it contains
output

# Diagnosis convergence with a trace plot
plot(output$entropy,ylab="Entropy",type="l")

# Show first three partitions
output$partitions[1:3,]

# Posterior distribution of the number of subsets
table(output$n.subsets)/length(output$n.subsets)

## ----loglikelihoodcontribution-------------------------------------------
jainneal.log.likelihood <- function(i,parameter) {
  dnorm(data[i],mean=parameter,sd=1/sqrt(lambda),log=TRUE)
}

## ----sampleparameter-----------------------------------------------------
jainneal.sample <- function(subset,parameter) {
  if ( length(subset) == 0 ) {
    rnorm(1,mean=mu0,sd=1/sqrt(lambda0))
  } else {
    precision <- lambda0 + length(subset)*lambda
    mean <- (lambda0*mu0 + lambda*sum(data[subset]))/precision
    rnorm(1,mean=mean,sd=1/sqrt(precision))
  }
}

## ----mcmcparamters2, tidy=FALSE------------------------------------------
mcmc.params <- mcmc.parameters(
  log.density.NAME="jainneal.log.likelihood",
  sample.NAME="jainneal.sample")

## ----collect2------------------------------------------------------------
dist <- ewens(mass(1.0,fixed=TRUE),length(data),names=names(data))
mcmc <- collect(dist,n.draws=NDRAWS,mcmc.parameters=mcmc.params)

## ----process2------------------------------------------------------------
output <- process(mcmc)

## ----analysis2-----------------------------------------------------------
# See what it contains
output

# Show first three partitions
output$partitions[1:3,]

# ... and the associated parameters
output$parameters[1:3]

# Posterior distribution of the number of subsets
table(output$n.subsets)/length(output$n.subsets)

# Posterior estimates under squared error loss
params <- lapply(output$parameters,unlist)
params <- do.call(rbind,lapply(1:nrow(output$partitions),function(i) {
  params[[i]][output$partitions[i,]]
}))
estimates <- apply(params,2,mean)

# Note shrinkage to cluster means
plot(data,estimates-data)
abline(h=0)

## ----morepriors, tidy=FALSE----------------------------------------------
a  <- 2.5; b  <- 0.02
c0 <- 2;   d0 <- 2
m0 <- 0;   p0 <- 0.5
a0 <- 3;   b0 <- 3
dist <- ewens(mass(c0,d0,fixed=FALSE),length(data),names=names(data))
mcmc <- collect(dist,n.draws=1,mcmc.parameters=mcmc.params)
n.samples <- NDRAWS
results <- matrix(NA,nrow=n.samples,ncol=3)
results[1,] <- c(lambda,mu0,lambda0)
for ( i in 2:n.samples ) {
  mcmc <- collect(mcmc,n.draws=1)
  state <- current.state(mcmc)
  parameters <- unlist(state$parameters)
  lambda  <- rgamma(1, a + 0.5*length(data),
                       b + 0.5*sum((data-parameters[state$partition])^2))
  precision <- p0 + length(parameters)*lambda0
  mean <- (p0*m0 + lambda0*sum(parameters))/precision
  mu0 <- rnorm(1,mean,1/sqrt(precision))
  lambda0 <- rgamma(1, a0 + 0.5*length(parameters),
                       b0 + 0.5*sum((parameters-mu0)^2))
  results[i,] <- c(lambda,mu0,lambda0)
}
output <- process(mcmc)
mcmc$proc.time

## ----compare, tidy=FALSE-------------------------------------------------
lambda.density <- density(results[,1])
curve(dgamma(x,a,b),0,300,col="red", ylim=c(0,max(lambda.density$y)),
  main=expression(paste("Prior and Posterior on ",lambda)),
  ylab="Density",
  xlab=expression(lambda))
lines(density(results[,1]))

## ----pairwiseprobabilities-----------------------------------------------
pp <- pairwise.probabilities(mcmc)
as.matrix(pp)

## ----partitionestimate---------------------------------------------------
estimate <- estimate.partition(mcmc)
estimate

## ----confidence----------------------------------------------------------
conf <- confidence(pp,estimate)
conf

## ----confidencePlot------------------------------------------------------
plot(conf)


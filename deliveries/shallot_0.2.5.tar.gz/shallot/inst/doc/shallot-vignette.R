## ----setup, include=FALSE------------------------------------------------
library(knitr)
out.format <- knitr::opts_knit$get("out.format")
opts_chunk$set(out.width = '500px', fig.width = 6, fig.height = 6, dpi = 150)

## ----eval=FALSE----------------------------------------------------------
#  install.packages("rscala")
#  install.packages("shallot_0.2.3.tar.gz", type = "source")

## ------------------------------------------------------------------------
library("shallot")

## ------------------------------------------------------------------------
shallot.load()
data <- c(a = -1.48, b = -1.40, c = -1.16, d = -1.08, e = -1.02, f = 0.14, g = 0.51,
          h = 0.53, i = 0.78)

## ------------------------------------------------------------------------
lambda  <- 0.1^-2
mu0     <- 0.0
lambda0 <- 1.0^-2

## ------------------------------------------------------------------------
jainneal.log.predictive.density <- function(i, subset) {
  precision <- lambda0 + length(subset) * lambda
  mean <- (lambda0 * mu0 + lambda * sum(data[subset])) / precision
  dnorm(data[i], mean = mean, sd = 1 / sqrt(lambda * precision / (precision + lambda)),
        log = TRUE)
}

## ------------------------------------------------------------------------
mcmc.params <- mcmc.parameters(log.density = jainneal.log.predictive.density)

## ------------------------------------------------------------------------
NDRAWS <- 100
dist <- ewens(mass(1.0, fixed = TRUE), length(data))

## ------------------------------------------------------------------------
mcmc <- collect(dist, n.draws = NDRAWS, mcmc.parameters = mcmc.params)

## ------------------------------------------------------------------------
mcmc <- collect(mcmc, n.draws = NDRAWS)

## ------------------------------------------------------------------------
output <- process(mcmc)

## ------------------------------------------------------------------------
# See what it contains
output

# Diagnosis convergence with a trace plot
plot(output$entropy, ylab = "Entropy", type = "l")

# Show first three partitions
output$partitions[1:3, ]

# Posterior distribution of the number of subsets
table(output$n.subsets) / length(output$n.subsets)

## ------------------------------------------------------------------------
jainneal.log.likelihood <- function(i, parameter) {
  dnorm(data[i], mean = parameter, sd = 1 / sqrt(lambda), log = TRUE)
}

## ------------------------------------------------------------------------
jainneal.sample <- function(subset, parameter) {
  if ( length(subset) == 0 ) {
    rnorm(1, mean = mu0, sd = 1 / sqrt(lambda0))
  } else {
    precision <- lambda0 + length(subset) * lambda
    mean <- (lambda0 * mu0 + lambda * sum(data[subset])) / precision
    rnorm(1, mean = mean, sd = 1 / sqrt(precision))
  }
}

## ------------------------------------------------------------------------
mcmc.params <- mcmc.parameters(
    log.density = jainneal.log.likelihood,
    sample = jainneal.sample)

## ------------------------------------------------------------------------
dist <- ewens(mass(1.0, fixed = TRUE), length(data), names = names(data))
mcmc <- collect(dist, n.draws = NDRAWS, mcmc.parameters = mcmc.params)

## ------------------------------------------------------------------------
output <- process(mcmc)

## ------------------------------------------------------------------------
# See what it contains
output

# Show first three partitions
output$partitions[1:3, ]

# ... and the associated parameters
output$parameters[1:3]

# Posterior distribution of the number of subsets
table(output$n.subsets) / length(output$n.subsets)

# Posterior estimates under squared error loss
params <- lapply(output$parameters, unlist)
params <- do.call(rbind, lapply(1:nrow(output$partitions), function(i) {
  params[[i]][output$partitions[i, ]]
}))
estimates <- apply(params, 2, mean)

# Note shrinkage to cluster means
plot(data, estimates - data)
abline(h = 0)

## ------------------------------------------------------------------------
a  <- 2.5
b  <- 0.02
c0 <- 2
d0 <- 2
m0 <- 0
p0 <- 0.5
a0 <- 3
b0 <- 3
dist <- ewens(mass(c0, d0, fixed = FALSE), length(data), names = names(data))
mcmc <- collect(dist, n.draws = 1, mcmc.parameters = mcmc.params)
n.samples <- NDRAWS
results <- matrix(NA, nrow = n.samples, ncol = 3)
results[1, ] <- c(lambda, mu0, lambda0)
for ( i in 2:n.samples ) {
  mcmc <- collect(mcmc, n.draws = 1)
  state <- current.state(mcmc)
  parameters <- unlist(state$parameters)
  lambda  <- rgamma(1, a + 0.5 * length(data), b + 0.5 * sum((data - 
      parameters[state$partition])^2))
  precision <- p0 + length(parameters) * lambda0
  mean <- (p0 * m0 + lambda0 * sum(parameters)) / precision
  mu0 <- rnorm(1, mean, 1 / sqrt(precision))
  lambda0 <- rgamma(1, a0 + 0.5 * length(parameters), b0 + 0.5 * sum((parameters -
      mu0)^2))
  results[i, ] <- c(lambda, mu0, lambda0)
}
output <- process(mcmc)
mcmc$proc.time

## ------------------------------------------------------------------------
lambda.density <- density(results[, 1])
curve(dgamma(x, a, b), 0, 300, col = "red", ylim = c(0, max(lambda.density$y)),
    main = expression(paste("Prior and Posterior on ", lambda)), ylab = "Density",
    xlab = expression(lambda))
lines(density(results[, 1]))

## ------------------------------------------------------------------------
pp <- pairwise.probabilities(mcmc)
as.matrix(pp)

## ------------------------------------------------------------------------
estimate <- estimate.partition(mcmc)
estimate

## ------------------------------------------------------------------------
conf <- confidence(pp, estimate)
conf

## ------------------------------------------------------------------------
plot(conf)


##########################
#### Not exported
##########################

msg <- function(x,fmtstr="%Y-%m-%d %r") {
  cat(format(Sys.time(),fmtstr),": ",x,"\n",sep="")
}

matrixOfPartitionsToShallotSamples <- function(samples) {
  samples <- E$s$do("scala.collection.immutable.List")$matrixToPartitions(samples)
  names <- if ( is.null(colnames(samples)) ) paste("c",1:ncol(samples),sep="")
  else colnames(samples)
  result <- list(jobjRef=list(samples=samples,names=names))
  class(result) <- "shallot.samples.raw"
  samples <- result
}

labels2partition <- function(x) {
  if ( ! inherits(x,"ScalaInterpreterReference") ) x <- E$s$do("org.ddahl.shallot.r.RInterface")$partition(as.integer(x))
  x
}

partition2labels <- function(x,names) {
  p <- x$toLabels() + 1L
  names(p) <- names
  p
}





##########################
#### Exported
##########################

# Adjusted Rand Index
adj.rand.index <- function(c1,c2) {
  n <- length(c1)
  if ( length(c2) != n ) stop("Clustering must be the same length.")
  t1  <- table(c1)
  t2  <- table(c2)
  t12 <- table(c1,c2)
  expected <- sum(choose(t1,2)) * sum(choose(t2,2)) / choose(n,2)
  numerator <- sum(choose(t12,2)) - expected
  denominator <- 0.5*(sum(choose(t1,2))+sum(choose(t2,2))) - expected
  numerator / denominator
}

# adj.rand.index(c(1,1,1,2,2,2,3,3,3),c(1,1,1,1,1,1,2,2,2))





# Mass
mass <- function(...,fixed=TRUE) {
  x <- c(...)
  value <- 1.2
  shape <- 2.5
  rate <- 2
  if ( length(x) == 0 ) {
  } else if ( length(x) == 1 ) {
    value <- as.double(x[1])
  } else if ( length(x) == 2 ) {
    if ( fixed ) stop("'fixed' should be FALSE if distribution parameters are specified.")
    shape <- as.double(x[1])
    rate <- as.double(x[2])
  } else stop("Incorrect number of arguments.")
  jobjRef <- E$s$do("org.ddahl.shallot.parameter.Mass")$apply(value)
  factoryJobjRef <- if ( fixed ) {
    E$s$do("org.ddahl.shallot.parameter.Mass")$factory(value)
  } else {
    E$s$do("org.ddahl.shallot.parameter.Mass")$factory(shape,rate,E$s$do("org.apache.commons.math3.random.RandomDataGenerator")$new())
  }
  result <- list(value=value,shape=shape,rate=rate,fixed=fixed,jobjRef=jobjRef,factoryJobjRef=factoryJobjRef)
  class(result) <- "shallot.mass"
  result
}

print.shallot.mass <- function(x, ...) {
  if ( x$fixed ) cat("mass fixed at ",x$value,"\n",sep="")
  else cat("mass sampled from Gamma(shape=",x$shape,",rate=",x$rate,")\n",sep="")
}

# mass()
# mass(2.3)
# mass(1,fixed=FALSE)
# mass(3,4,fixed=FALSE)





# Discount
discount <- function(...,fixed=TRUE) {
  x <- c(...)
  value <- 0.05
  shape1 <- 1
  shape2 <- 1
  if ( length(x) == 0 ) {
  } else if ( length(x) == 1 ) {
    value <- as.double(x[1])
  } else if ( length(x) == 2 ) {
    if ( fixed ) stop("'fixed' should be FALSE if distribution parameters are specified.")
    shape1 <- as.double(x[1])
    shape2 <- as.double(x[2])
  } else stop("Incorrect number of arguments.")
  jobjRef <- E$s$do("org.ddahl.shallot.parameter.Discount")$apply(value)
  factoryJobjRef <- if ( fixed ) {
    E$s$do("org.ddahl.shallot.parameter.Discount")$factory(value)
  } else {
    E$s$do("org.ddahl.shallot.parameter.Discount")$factory(shape1,shape2,E$s$do("org.apache.commons.math3.random.RandomDataGenerator")$new())
  }
  result <- list(value=value,shape1=shape1,shape2=shape2,fixed=fixed,jobjRef=jobjRef,factoryJobjRef=factoryJobjRef)
  class(result) <- "shallot.discount"
  result
}

print.shallot.discount <- function(x, ...) {
  if ( x$fixed ) cat("discount fixed at ",x$value,"\n",sep="")
  else cat("discount sampled from Beta(shape1=",x$shape1,",shape2=",x$shape2,")\n",sep="")
}

# discount()
# discount(0.1)
# discount(0.1,fixed=FALSE)
# discount(3,4,fixed=FALSE)





# Distance
distance <- function(x,multiplier=1.00) {
  xx <- as.matrix(x)
  if ( min(xx[lower.tri(xx)]) <= 0 ) xx <- xx + multiplier*min(xx[xx>0])
  names <- if ( is.null(colnames(xx)) ) {
    paste("c",1:ncol(xx),sep="")
  } else {
    colnames(xx)
  }
  y <- xx
  jobjRef <- E$s$do("org.ddahl.shallot.parameter.Distance")$apply(y,FALSE)
  result <- list(n.items=jobjRef$nItems(),names=names,jobjRef=jobjRef)
  class(result) <- "shallot.distance"
  result
}

print.shallot.distance <- function(x, ...) {
  cat("distance for ",x$n.items," items\n",sep="")
}

as.matrix.shallot.distance <- function(x, ...) {
  y <- x$jobjRef$toArray()
  dimnames(y) <- list(x$names,x$names)
  y
}

# d <- distance(as.dist(dist(USArrests)))
# as.matrix(d)





# Permutation
permutation <- function(...,n.items=NULL,fixed=TRUE) {
  x <- c(...) - 1
  if ( length(x) == 0 ) {
    if ( is.null(n.items) ) stop("'n.items' must be specified if permutation is not given.")
    if ( fixed ) stop("'fixed' must be FALSE if permutation is not given.")
    jobjRef <- E$s$do("org.ddahl.shallot.parameter.Permutation")$apply(as.integer(seq(n.items)-1))
  } else {
    if ( is.null(n.items) ) n.items <- length(x)
    if ( n.items != length(x) ) stop("'n.items' is not equal to the length of the permutation.")
    jobjRef <- E$s$do("org.ddahl.shallot.parameter.Permutation")$apply(as.integer(x))
  }
  result <- list(n.items=n.items,fixed=fixed,jobjRef=jobjRef)
  class(result) <- "shallot.permutation"
  result
}

print.shallot.permutation <- function(x, ...) {
  if ( x$fixed ) {
    y <- x$jobjRef$toString()
    width <- 50
    if ( nchar(y) > width ) y <- paste(strtrim(y,width-3),"...",sep="")
    cat("permutation of ",x$n.items," items fixed at ",y,"\n",sep="")
  }
  else cat("permutation of ",x$n.items," items sampled uniformly\n",sep="")
}

# permutation(n.items=30,fixed=FALSE)
# permutation(2,3,4,1)
# permutation(2,3,4,1,fixed=FALSE)





# Temperature
temperature <- function(...,fixed=TRUE,max.temperature=Inf) {
  x <- c(...)
  value <- 3
  shape <- 2
  rate <- 0.5
  if ( length(x) == 0 ) {
  } else if ( length(x) == 1 ) {
    if ( ! fixed ) stop("'fixed' should be TRUE if value is specified.")
    value <- min(as.double(x[1]),0.99*max.temperature)
  } else if ( length(x) == 2 ) {
    if ( fixed ) stop("'fixed' should be FALSE if distribution parameters are specified.")
    shape <- as.double(x[1])
    rate <- as.double(x[2])
  } else stop("Incorrect number of arguments.")
  result <- list(value=value,shape=shape,rate=rate,fixed=fixed)
  class(result) <- "shallot.temperature"
  result
}

print.shallot.temperature <- function(x, ...) {
  if ( x$fixed ) cat("temperature fixed at ",x$value,"\n",sep="")
  else cat("temperature sampled from Gamma(shape=",x$shape,",rate=",x$rate,")\n",sep="")
}

# temperature()
# temperature(2,4,fixed=FALSE)
# temperature(2)





# Decay functions
decay.reciprocal <- function(...,fixed=TRUE,distance=NULL) {
  max.temperature <- if ( ! is.null(distance) ) {
    x1 <- -log(.Machine$double.xmin)/log(distance$jobjRef$max())
    x2 <- -(log(.Machine$double.xmax)-log(distance$n.items))/log(distance$jobjRef$min())
    x <- Inf
    if ( x1 > 0 ) x <- min(x,x1)
    if ( x2 > 0 ) x <- min(x,x2)
    x
  } else Inf
  decay.generic(...,type="reciprocal",multiplier=1.01,fixed=fixed,max.temperature=max.temperature)
}

decay.exponential <- function(...,fixed=TRUE,distance=NULL) {
  max.temperature <- if ( ! is.null(distance) ) {
    x1 <- -log(.Machine$double.xmin)/distance$jobjRef$max()
    x2 <- -(log(.Machine$double.xmax)-log(distance$n.items))/distance$jobjRef$min()
    x <- Inf
    if ( x1 > 0 ) x <- min(x,x1)
    if ( x2 > 0 ) x <- min(x,x2)
    x
  } else Inf
  decay.generic(...,type="exponential",multiplier=1.01,fixed=fixed,max.temperature=max.temperature)
}

decay.subtraction <- function(...,multiplier=1.01,fixed=TRUE,distance=NULL) {
  max.temperature <- if ( ! is.null(distance) ) {
    d1 <- ( multiplier*distance$jobjRef$max() - distance$jobjRef$min() )
    d2 <- ( multiplier*distance$jobjRef$max() - distance$jobjRef$max() )
    x1 <- log(.Machine$double.xmin)/log(d2)
    x2 <- (log(.Machine$double.xmax)-log(distance$n.items))/log(d1)
    x <- Inf
    if ( x1 > 0 ) x <- min(x,x1)
    if ( x2 > 0 ) x <- min(x,x2)
    x
  } else Inf
  decay.generic(...,multiplier=multiplier,type="subtraction",fixed=fixed,max.temperature=max.temperature)
}

decay.generic <- function(...,multiplier,type,fixed,max.temperature) {
  result <- list(type=type,multiplier=multiplier,temperature=temperature(...,fixed=fixed,max.temperature=max.temperature))
  class(result) <- "shallot.decay"
  result
}

print.shallot.decay <- function(x, ...) {
  cat(x$type,"decay function with ")
  if ( x$temperature$fixed ) cat("temperature fixed at ",x$temperature$value,"\n",sep="")
  else cat("temperature sampled from Gamma(shape=",x$temperature$shape,",rate=",x$temperature$rate,")\n",sep="")
}

# decay.reciprocal(4)
# decay.reciprocal(2,4,fixed=FALSE)
# decay.reciprocal(Inf,distance=d)
# decay.exponential(4)
# decay.exponential(2,4,fixed=FALSE)
# decay.exponential(Inf,distance=d)
# decay.subtraction(4)
# decay.subtraction(2,4,fixed=FALSE)
# decay.subtraction(Inf,distance=d)





# Attraction
attraction <- function(distance, permutation, decay) {
  fixed <- permutation$fixed && decay$temperature$fixed
  jobjRef <- if ( fixed ) {
    decayJobjRef <- if ( decay$type == "reciprocal" ) {
      E$s$do("org.ddahl.shallot.parameter.decay.ReciprocalDecayFactory")$apply(decay$temperature$value)
    } else if ( decay$type == "exponential" ) {
      E$s$do("org.ddahl.shallot.parameter.decay.ExponentialDecayFactory")$apply(decay$temperature$value)
    } else if ( decay$type == "subtraction" ) {
      tmpObj <- E$s$do("org.ddahl.shallot.parameter.decay.SubtractionDecayFactory")$apply(decay$multiplier*distance$jobjRef$max())
      tmpObj$apply(decay$temperature$value)
    } else stop("Unrecognized decay function.")
    p <- permutation$jobjRef
    E$s$do("org.ddahl.shallot.distribution.Attraction")$apply(distance$jobjRef,permutation$jobjRef,decayJobjRef)
  } else NULL
  result <- list(n.items=distance$n.items, distance=distance, permutation=permutation, decay=decay, fixed=fixed, names=distance$names, jobjRef=jobjRef)
  class(result) <- "shallot.attraction"
  result
}

print.shallot.attraction <- function(x, ...) {
  cat("attraction for ",x$n.items," items:\n",sep="")
  cat("  ")
  print(x$distance)
  cat("  ")
  print(x$permutation)
  cat("  ")
  print(x$decay)
}

as.matrix.shallot.attraction <- function(x, ...) {
  y <- x$jobjRef$toArray()
  dimnames(y) <- list(x$names,x$names)
  y
}

# a <- attraction(d,permutation(n.items=d$n.items,fixed=FALSE),decay.exponential(fixed=FALSE))





# Ewens
ewens <- function(mass, n.items, names=paste("c",1:n.items,sep="")) {
  result <- list(mass=mass,n.items=n.items,names=names)
  class(result) <- "shallot.distribution.ewens"
  result
}

print.shallot.distribution.ewens <- function(x, ...) {
  cat("Ewens distribution with:\n")
  cat("  ",x$n.items," items\n",sep="")
  cat("  ")
  print(x$mass)
}

# ewens(mass(fixed=FALSE),50)





# Ewens Pitman
ewens.pitman <- function(mass, discount, n.items, names=paste("c",1:n.items,sep="")) {
  result <- list(mass=mass,discount=discount,n.items=n.items,names=names)
  class(result) <- "shallot.distribution.ewensPitman"
  result
}

print.shallot.distribution.ewensPitman <- function(x, ...) {
  cat("Ewens Pitman distribution with:\n")
  cat("  ",x$n.items," items\n",sep="")
  cat("  ")
  print(x$mass)
  cat("  ")
  print(x$discount)
}

# ewens.pitman(mass(fixed=FALSE),discount(fixed=FALSE),50)





# Ewens Attraction
ewens.attraction <- function(mass, attraction) {
  result <- list(mass=mass,attraction=attraction,n.items=attraction$n.items,names=attraction$names)
  class(result) <- "shallot.distribution.ewensAttraction"
  result
}

print.shallot.distribution.ewensAttraction <- function(x, ...) {
  cat("Ewens Attraction distribution with:\n")
  cat("  ")
  print(x$mass)
  x <- capture.output(print(x$attraction))
  cat(paste("  ",x,"\n",sep=""))
}

# ewens.attraction(mass(fixed=FALSE),a)




# Ewens Pitman Attraction
ewens.pitman.attraction <- function(mass, discount, attraction) {
  result <- list(mass=mass,discount=discount,attraction=attraction,n.items=attraction$n.items,names=attraction$names)
  class(result) <- "shallot.distribution.ewensPitmanAttraction"
  result
}

print.shallot.distribution.ewensPitmanAttraction <- function(x, ...) {
  cat("Ewens Pitman Attraction distribution with:\n")
  cat("  ")
  print(x$mass)
  cat("  ")
  print(x$discount)
  x <- capture.output(print(x$attraction))
  cat(paste("  ",x,"\n",sep=""))
}

# ewens.pitman.attraction(mass(fixed=FALSE),discount(fixed=FALSE),a)





# Distance dependent Chinese restaurant process (ddCRP)
ddcrp <- function(mass, attraction) {
  result <- list(mass=mass,attraction=attraction,n.items=attraction$n.items,names=attraction$names)
  class(result) <- "shallot.distribution.ddcrp"
  result
}

print.shallot.distribution.ddcrp <- function(x, ...) {
  cat("ddCRP distribution with:\n")
  cat("  ")
  print(x$mass)
  x <- capture.output(print(x$attraction))
  cat(paste("  ",x,"\n",sep=""))
}

# ddcrp(mass(2.3),a)





# PPMx similarities
ppmx.similarity.categorical <- function(covariates, levels=NULL, alpha=0.5) {
  if ( ! is.matrix(covariates) ) stop("Covariates must be a matrix.")
  storage.mode(covariates) <- "character"
  n.items <- nrow(covariates)
  names <- rownames(covariates)
  covariates <- t(covariates)
  levels <- if ( is.null(levels) ) sort(unique(covariates))
  else {
    l <- as.character(levels)
    if ( ! all(unique(covariates) %in% l) ) stop("covariates contains some values that are not in levels.")
    l
  }
  alpha <- if ( length(alpha) == 1 ) as.numeric(rep(alpha,times=length(levels)))
  else {
    a <- as.numeric(alpha)
    if ( length(a) != length(levels) ) stop("alpha must have length 1 or have length equal to that of levels.") 
  }
  jobjRef <- E$s$do("org.ddahl.shallot.distribution.PPMxSimilarityCategorical")$new(covariates,levels,alpha)
  result <- list(jobjRef=jobjRef,n.items=n.items,names=names)
  class(result) <- "shallot.ppmx.similarity"
  result
}

ppmx.similarity.continuous <- function(covariates, mu0=NULL, n0=NULL, alpha=NULL, beta=NULL) {
  if ( ! is.matrix(covariates) ) stop("Covariates must be a matrix.")
  storage.mode(covariates) <- "numeric"
  n.items <- nrow(covariates)
  names <- rownames(covariates)
  covariates <- scale(covariates)
  covariates <- t(covariates)
  hyperparametersAreNull <- c(is.null(mu0),is.null(n0),is.null(alpha),is.null(beta))
  if ( any(hyperparametersAreNull) && ! all(hyperparametersAreNull) ) stop("If any hyperparameter is null, all must be null.")
  jobjRef <- if ( all(hyperparametersAreNull) ) {
    E$s$do("org.ddahl.shallot.distribution.PPMxSimilarityContinuousMean")$new(covariates)
  } else {
    mu0 <- as.numeric(mu0)[1]
    n0 <- as.numeric(n0)[1]
    alpha <- as.numeric(alpha)[1]
    beta <- as.numeric(beta)[1]
    E$s$do("org.ddahl.shallot.distribution.PPMxSimilarityContinuousMeanVariance")$new(covariates,mu0,n0,alpha,beta)
  }
  result <- list(jobjRef=jobjRef,n.items=n.items,names=names)
  class(result) <- "shallot.ppmx.similarity"
  result
}

ppmx.similarity.composite <- function(...) {
  similarities <- list(...)
  if ( length(similarities) == 0 ) stop("At least one argument must be provided.")
  x <- E$s$do("Seq")$"empty[org.ddahl.shallot.distribution.PPMxSimilarity]"()
  n.items <- similarities[[1]]$n.items
  names <- similarities[[1]]$names
  for ( i in 1:length(similarities) ) {
    if ( class(similarities[[i]]) != "shallot.ppmx.similarity" ) stop("All arguments must be PPMx similarity functions.")
    if ( similarities[[i]]$n.items != n.items ) stop("Inconsistent number of items.")
    if ( !all(similarities[[i]]$names == names)) stop("Inconsistent names.")
    x <- x$":+"(similarities[[i]]$jobjRef)
  }
  jobjRef <- E$s$do("org.ddahl.shallot.distribution.PPMxSimilarityComposite")$new(x)
  result <- list(jobjRef=jobjRef,n.items=n.items,names=names)
  class(result) <- "shallot.ppmx.similarity"
  result
}





# Product partition model with covariates (PPMx)
ppmx <- function(mass, similarity) {
  result <- list(mass=mass,attraction=similarity,n.items=nrow(covariates),names=rownames(covariates))
  class(result) <- "shallot.distribution.ppmx"
  result
}

print.shallot.distribution.ppmx <- function(x, ...) {
  cat("PPMx distribution with:\n")
  cat("  ")
  print(x$mass)
  cat(paste("  similarity: ",x$attraction$jobjRef[['type']],"\n",sep=""))
}

# ppmx(mass(2.3),USArrests,"continuous")





# Distribution of the number of subsets
random.q <- function(x,n.samples) {
  if ( all(class(x) == "shallot.distribution.ewens") ) {
    E$s$do("org.ddahl.shallot.distribution.Ewens")$sampleNumberOfSubsets(as.integer(x$n.items),x$mass$factoryJobjRef,as.integer(n.samples))
  } else if ( all(class(x) == "shallot.distribution.ewensAttraction") ) {
    E$s$do("org.ddahl.shallot.distribution.EwensAttraction")$sampleNumberOfSubsets(as.integer(x$n.items),x$mass$factoryJobjRef,as.integer(n.samples))
  } else if (  all(class(x) == "shallot.distribution.ewensPitman") ) {
    E$s$do("org.ddahl.shallot.distribution.EwensPitman")$sampleNumberOfSubsets(as.integer(x$n.items),x$mass$factoryJobjRef,x$discount$factoryJobjRef,as.integer(n.samples))
  } else if (  all(class(x) == "shallot.distribution.ewensPitmanAttraction") ) {
    E$s$do("org.ddahl.shallot.distribution.EwensPitmanAttraction")$sampleNumberOfSubsets(as.integer(x$n.items),x$mass$factoryJobjRef,x$discount$factoryJobjRef,as.integer(n.samples))
  } else stop("Unrecognized distribution.")
}

# random.q(ewens.pitman.attraction(mass(fixed=FALSE),discount(fixed=FALSE),a),1000)

probability.q <- function(x,n.subsets) {
  if ( ! x$mass$fixed ) stop("'mass' must be fixed, but emperical estimates are available through random.q function.")
  if ( all(class(x) == "shallot.distribution.ewens") ) {
    E$s$do("org.ddahl.shallot.distribution.Ewens")$probabilityNumberOfSubsets(as.integer(x$n.items),as.integer(n.subsets),x$mass$jobjRef)
  } else if ( all(class(x) == "shallot.distribution.ewensAttraction") ) {
    E$s$do("org.ddahl.shallot.distribution.EwensAttraction")$probabilityNumberOfSubsets(as.integer(x$n.items),as.integer(n.subsets),x$mass$jobjRef)
  } else {
    if ( ! x$discount$fixed ) stop("'discount' must be fixed, but emperical estimates are available through random.q function.")
    if (  all(class(x) == "shallot.distribution.ewensPitman") ) {
      E$s$do("org.ddahl.shallot.distribution.EwensPitman")$probabilityNumberOfSubsets(as.integer(x$n.items),as.integer(n.subsets),x$mass$jobjRef,x$discount$jobjRef)
    } else if (  all(class(x) == "shallot.distribution.ewensPitmanAttraction") ) {
      E$s$do("org.ddahl.shallot.distribution.EwensPitmanAttraction")$probabilityNumberOfSubsets(as.integer(x$n.items),as.integer(n.subsets),x$mass$jobjRef,x$discount$jobjRef)
    } else stop("Unrecognized distribution.")
  }
}

# probability.q(ewens.pitman.attraction(mass(n.items=a$n.items,fixed=TRUE),discount(0.1,fixed=TRUE),a),4)

average.q <- function(x) {
  if ( ! x$mass$fixed ) stop("'mass' must be fixed, but emperical estimates are available through random.q function.")
  if ( all(class(x) == "shallot.distribution.ewens") ) {
    E$s$do("org.ddahl.shallot.distribution.Ewens")$meanNumberOfSubsets(as.integer(x$n.items),x$mass$jobjRef)
  } else if ( all(class(x) == "shallot.distribution.ewensAttraction") ) {
    E$s$do("org.ddahl.shallot.distribution.EwensAttraction")$meanNumberOfSubsets(as.integer(x$n.items),x$mass$jobjRef)
  } else {
    if ( ! x$discount$fixed ) stop("'discount' must be fixed, but emperical estimates are available through random.q function.")
    if (  all(class(x) == "shallot.distribution.ewensPitman") ) {
      E$s$do("org.ddahl.shallot.distribution.EwensPitman")$meanNumberOfSubsets(as.integer(x$n.items),x$mass$jobjRef,x$discount$jobjRef)
    } else if (  all(class(x) == "shallot.distribution.ewensPitmanAttraction") ) {
      E$s$do("org.ddahl.shallot.distribution.EwensPitmanAttraction")$meanNumberOfSubsets(as.integer(x$n.items),x$mass$jobjRef,x$discount$jobjRef)
    } else stop("Unrecognized distribution.")
  }
}

# average.q(ewens.pitman.attraction(mass(2,fixed=TRUE),discount(0.1,fixed=TRUE),a))

variance.q <- function(x) {
  if ( ! x$mass$fixed ) stop("'mass' must be fixed, but emperical estimates are available through random.q function.")
  if ( all(class(x) == "shallot.distribution.ewens") ) {
    E$s$do("org.ddahl.shallot.distribution.Ewens")$varianceNumberOfSubsets(as.integer(x$n.items),x$mass$jobjRef)
  } else if ( all(class(x) == "shallot.distribution.ewensAttraction") ) {
    E$s$do("org.ddahl.shallot.distribution.EwensAttraction")$varianceNumberOfSubsets(as.integer(x$n.items),x$mass$jobjRef)
  } else {
    if ( ! x$discount$fixed ) stop("'discount' must be fixed, but emperical estimates are available through random.q function.")
    if (  all(class(x) == "shallot.distribution.ewensPitman") ) {
      stop("Unsupported distribution, but emperical estimates are available through random.q function.")
    } else if (  all(class(x) == "shallot.distribution.ewensPitmanAttraction") ) {
      stop("Unsupported distribution, but emperical estimates are available through random.q function.")
    } else stop("Unrecognized distribution.")
  }
}

# variance.q(ewens.attraction(mass(2,fixed=TRUE),a))





# MCMC tuning
mcmc.parameters <- function(log.density=NULL,sample=NULL,mass.rw.sd=0.5,discount.rw.sd=0.1,permutation.grab.size=10,temperature.rw.sd=0.5,n.iterations.per.sample=1) {
  usesPredictiveDensity <- FALSE
  sampling.model <- if ( is.null(log.density) ) NULL
  else {
    callBackEngine <- E$s$.R
    if ( is.null(sample) ) {
      usesPredictiveDensity <- TRUE
      sample <- NULL
    }
    argsNames <- names(formals(log.density))
    if (usesPredictiveDensity) {
      if ( ( length(argsNames) != 2 ) || ( ! all( argsNames == c("i","subset") ) ) )
        stop("Signature of the log density function should be exactly c('i','subset').")
    } else {
      if ( ( length(argsNames) != 2 ) || ( ! all( argsNames == c("i","parameter") ) ) )
        stop("Signature of the log density function should be exactly c('i','parameter').")
      argsNames <- names(formals(sample))
      if ( ( length(argsNames) != 2 ) || ( ! all( argsNames == c("subset","parameter") ) ) )
        stop("Signature of the sample function should be exactly c('subset','parameter').")
    }
    log.density.REFERENCE <- intpWrap(E$s,log.density)
    sample.REFERENCE <- intpWrap(E$s,sample)
    E$s$do("org.ddahl.shallot.r.RAdapter")$apply(callBackEngine,as.logical(usesPredictiveDensity),log.density.REFERENCE,sample.REFERENCE)
  }
  result <- list(
    mass.rw.sd=as.double(mass.rw.sd),
    discount.rw.sd=as.double(discount.rw.sd),
    permutation.grab.size=as.integer(permutation.grab.size),
    temperature.rw.sd=as.double(temperature.rw.sd),
    n.iterations.per.sample=as.integer(n.iterations.per.sample),
    uses.predictive.density=as.logical(usesPredictiveDensity),
    sampling.model=sampling.model)
  class(result) <- "shallot.mcmc.parameters"
  result
}





# Collect
collect <- function(x,n.draws=1000,mcmc.parameters=NULL,parallel=TRUE,seed=NULL,reset=FALSE) {
  start.time <- proc.time()
  if ( n.draws < 1 ) stop("n.draws must be at least 1.")
  if ( substr(class(x),1,nchar("shallot.distribution.")) == "shallot.distribution." ) {
    pm <- x
    rdg <- E$s$do("org.apache.commons.math3.random.RandomDataGenerator")$new()
    if ( ! is.null(seed) ) rdg$reSeed(seed)
    distribution.name <- class(pm)
    mass <- as.double(pm$mass$value)
    massShape <- as.double(pm$mass$shape)
    massRate <- as.double(pm$mass$rate)
    massFixed <- as.logical(pm$mass$fixed)
    if ( distribution.name %in% c("shallot.distribution.ewensPitman","shallot.distribution.ewensPitmanAttraction") ) {
      discount <- as.double(pm$discount$value)
      discountShape1 <- as.double(pm$discount$shape1)
      discountShape2 <- as.double(pm$discount$shape2)
      discountFixed <- as.logical(pm$discount$fixed)
    } else {
      discount <- 0.0
      discountShape1 <- 0.0
      discountShape2 <- 0.0
      discountFixed <- TRUE
    }
    if ( distribution.name %in% c("shallot.distribution.ewensAttraction","shallot.distribution.ewensPitmanAttraction","shallot.distribution.ddcrp") ) {
      distance <- pm$attraction$distance$jobjRef
      permutation <- pm$attraction$permutation$jobjRef
      permutationFixed <- as.logical(pm$attraction$permutation$fixed)
      decayString <- as.character(pm$attraction$decay$type)
      decayMultiplier <- as.double(pm$attraction$decay$multiplier)
      temperature <- as.double(pm$attraction$decay$temperature$value)
      temperatureShape <- as.double(pm$attraction$decay$temperature$shape)
      temperatureRate <- as.double(pm$attraction$decay$temperature$rate)
      temperatureFixed <- as.logical(pm$attraction$decay$temperature$fixed)
    } else {
      distance <- E$s$.null
      permutation <- E$s$.null
      permutationFixed <- TRUE
      decayString <- ""
      decayMultiplier <- 1.0
      temperature <- 0.0
      temperatureShape <- 0.0
      temperatureRate <- 0.0
      temperatureFixed <- TRUE
    }
    if ( distribution.name == "shallot.distribution.ppmx" ) {
      ppmxSimilarity <- pm$attraction$jobjRef
    } else {
      ppmxSimilarity <- E$s$.null
    }
    if ( is.null(mcmc.parameters) ) {
      sampler <- E$s$do("org.ddahl.shallot.r.RInterface")$makeForwardSamplerForR(
        distribution.name,as.integer(pm$n.items),distance,
        mass,massShape,massRate,massFixed,
        discount,discountShape1,discountShape2,discountFixed,
        permutation,permutationFixed,
        decayString,decayMultiplier,
        temperature,temperatureShape,temperatureRate,temperatureFixed,ppmxSimilarity)
      augmentedSamples <- NULL
      samples <- E$s$do("org.ddahl.shallot.r.RInterface")$sampleForward(as.integer(n.draws),rdg,sampler,as.logical(parallel))
    } else {
      sampling.model <- if ( is.null(mcmc.parameters$sampling.model) ) {
        E$s$.null
      }
      else mcmc.parameters$sampling.model
      sampler <- E$s$do("org.ddahl.shallot.r.RInterface")$makeMCMCSamplerForR(
        distribution.name,as.integer(pm$n.items),distance,
        E$s$do("Tuple5")$apply(mass,massShape,massRate,massFixed,mcmc.parameters$mass.rw.sd),
        discount,discountShape1,discountShape2,discountFixed,mcmc.parameters$discount.rw.sd,
        permutation,permutationFixed,as.integer(min(mcmc.parameters$permutation.grab.size,pm$n.items)),
        decayString,decayMultiplier,
        temperature,temperatureShape,temperatureRate,temperatureFixed,mcmc.parameters$temperature.rw.sd,
        sampling.model)
      augmentedSamples <- E$s$do("org.ddahl.shallot.r.RInterface")$sampleMCMC(as.integer(n.draws),as.integer(mcmc.parameters$n.iterations.per.sample),rdg,sampler)
      samples <- E$s$do("org.ddahl.shallot.r.RInterface")$extractSamples(augmentedSamples)
    }
    n.samples <- samples$length()
    result <- list(proc.time=proc.time()-start.time,n.items=pm$n.items,n.samples=n.samples,names=x$names,mcmc.parameters=mcmc.parameters,jobjRef=list(rdg=rdg,samples=samples,sampler=sampler,augmentedSamples=augmentedSamples))
  } else if ( class(x) == "shallot.samples.raw" ) {
    if ( ! is.null(mcmc.parameters) ) stop("mcmc.parameters must be null when continuing.")
    if ( ! is.null(seed) ) stop("seed must be null when continuing.")
    if ( is.null(x$mcmc.parameters) ) {
      augmentedSamples <- NULL
      if ( reset ) {
        samples <- x$jobjRef$samples$take(as.integer(1))
      } else {
        samples <- E$s$do("org.ddahl.shallot.r.RInterface")$sampleForward(as.integer(n.draws),x$jobjRef$rdg,x$jobjRef$sampler,as.logical(parallel))
        samples <- E$s$do("org.ddahl.shallot.r.RInterface")$mergeSamples(samples,x$jobjRef$samples)
      }
    } else {
      if ( reset ) {
        augmentedSamples <- x$jobjRef$augmentedSamples$take(as.integer(1))
        samples <- x$jobjRef$samples$take(as.integer(1))
      } else {
        augmentedSamples <- E$s$do("org.ddahl.shallot.r.RInterface")$sampleMCMC(as.integer(n.draws),x$mcmc.parameters$n.iterations.per.sample,x$jobjRef$rdg,x$jobjRef$sampler)
        samples <- E$s$do("org.ddahl.shallot.r.RInterface")$extractSamples(augmentedSamples)
        samples <- E$s$do("org.ddahl.shallot.r.RInterface")$mergeSamples(samples,x$jobjRef$samples)
        augmentedSamples <- E$s$do("org.ddahl.shallot.r.RInterface")$mergeAugmentedSamples(augmentedSamples,x$jobjRef$augmentedSamples)
      }
    }
    if ( reset ) x$jobjRef$sampler$reset()
    n.samples <- samples$length()
    result <- list(proc.time=x$proc.time+(proc.time()-start.time),n.items=x$n.items,n.samples=n.samples,names=x$names,mcmc.parameters=x$mcmc.parameters,jobjRef=list(rdg=x$jobjRef$rdg,samples=samples,sampler=x$jobjRef$sampler,augmentedSamples=augmentedSamples))
  } else stop("First argument is not recognized.")
  class(result) <- "shallot.samples.raw"
  result
}

print.shallot.samples.raw <- function(x, ...) {
  cat("raw samples --- use the 'process' function to extract information\n")
}





# Process
process <- function(x, ...) {
  start.time <- proc.time()
  withParameters <- ! is.null(x$jobjRef$augmentedSamples) && ! is.null(x$mcmc.parameters) && ! x$mcmc.parameters$uses.predictive.density
  samples <- x$jobjRef$samples$reverse()
  labelsWithParameters <- samples$map(E$s[['env']]$mapper.toLabelsWithParameters)
  partitions <- labelsWithParameters$map(E$s[['env']]$mapper.toLabels)$toArray()
  colnames(partitions) <- x$names
  n.subsets <- samples$map(E$s[['env']]$mapper.nSubsets)$toArray()
  entropy <- samples$map(E$s[['env']]$mapper.entropy)$toArray()
  result <- list(partitions=partitions,n.subsets=n.subsets,entropy=entropy)
  if ( ! is.null(x$jobjRef$augmentedSamples) ) {
    recordMass <- x$jobjRef$sampler$recordMass()
    recordDiscount <- x$jobjRef$sampler$recordDiscount()
    recordPermutation <- x$jobjRef$sampler$recordPermutation()
    recordTemperature <- x$jobjRef$sampler$recordTemperature()
    augmentedSamples <- x$jobjRef$augmentedSamples$reverse()
    if ( recordMass )        result <- c(result,list(mass=       augmentedSamples$map(E$s[['env']]$mapper.mass       )$toArray()))
    if ( recordDiscount )    result <- c(result,list(discount=   augmentedSamples$map(E$s[['env']]$mapper.discount   )$toArray()))
    if ( recordTemperature ) result <- c(result,list(temperature=augmentedSamples$map(E$s[['env']]$mapper.temperature)$toArray()))
    if ( ! is.null(x$mcmc.parameters) ) {
      rates <- x$jobjRef$sampler$rates()
      names(rates) <- c("mass","discount","permutation","temperature")
      rates <- rates[c(recordMass,recordDiscount,recordPermutation,recordTemperature)]
      if ( withParameters ) {
        parameterReferences <- labelsWithParameters$map(E$s[['env']]$mapper.toParameters)$toArray()
        parameters <- list()
        length(parameters) <- length(n.subsets)
        for ( i in 1:length(parameters) ) {
          ri <- parameterReferences$apply(as.integer(i-1))
          tl <- list()
          nParams <- n.subsets[i]
          length(tl) <- nParams
          for ( j in 1:nParams ) {
            tl[[j]] <- intpUnwrap(E$s,ri$apply(as.integer(j-1)))
          }
          parameters[[i]] <- tl
        }
      } else parameters <- NULL
      result <- c(result,list(parameters=parameters,rates=rates))
    }
  }
  result <- c(result,list(proc.time=proc.time()-start.time))
  class(result) <- "shallot.samples"
  result
}

print.shallot.samples <- function(x, ...) {
  cat("samples --- list with elements: ",paste(names(x),collapse=", "),".\n",sep="")
}





# Current state
current.state <- function(x) {
  withParameters <- ! is.null(x$jobjRef$augmentedSamples) && ! is.null(x$mcmc.parameters) && ! x$mcmc.parameters$uses.predictive.density
  sample <- x$jobjRef$samples$head()
  labelsWithParameters <- E$s[['env']]$mapper.toLabelsWithParameters$apply(sample)
  partition <- labelsWithParameters$"_1"()
  names(partition) <- x$names
  if ( ! is.null(x$jobjRef$augmentedSamples) && ! is.null(x$mcmc.parameters) ) {
    if ( withParameters ) {
      parameterReferences <- labelsWithParameters$"_2"()
      parameters <- list()
      nParams <- parameterReferences$length()
      length(parameters) <- nParams
      for ( j in 1:nParams ) {
        parameters[[j]] <- intpUnwrap(E$s,parameterReferences$apply(as.integer(j-1)))
      }
    } else parameters <- NULL
    result <- list(partition=partition,parameters=parameters)
  } else result <- list(partition=partition)
  class(result) <- "shallot.state"
  result
}

print.shallot.state <- function(x, ...) {
  cat("partition:\n")
  print(x$partition)
  if ( ! is.null(x$parameters) ) {
    cat("\n")
    cat("parameters:\n")
    print(x$parameters)
  }
}





# Pairwise Probabilities
pairwise.probabilities <- function(x,parallel=TRUE) {
  start.time <- proc.time()
  if ( class(x) != "shallot.samples.raw" ) x <- matrixOfPartitionsToShallotSamples(x)
  jobjRef <- E$s$do("org.ddahl.shallot.parameter.partition.PairwiseProbability")$apply(x$jobjRef$samples,as.logical(parallel))
  result <- list(n.items=jobjRef$nItems(),names=x$names,proc.time=proc.time()-start.time,jobjRef=jobjRef)
  class(result) <- "shallot.pairwiseProbability"
  result
}

print.shallot.pairwiseProbability <- function(x, ...) {
  cat("pairwise probabilities for ",x$n.items," items --- use as.matrix function to obtain matrix\n",sep="")
}

as.matrix.shallot.pairwiseProbability <- function(x, ...) {
  y <- x$jobjRef$toArray()
  z <- x$names
  dimnames(y) <- list(z,z)
  y
}





# Estimate partition
estimate.partition <- function(x, pairwise.probabilities=NULL, max.subsets=0, max.scans=0, parallel=TRUE) {
  start.time <- proc.time()
  if ( class(x) != "shallot.samples.raw" ) x <- matrixOfPartitionsToShallotSamples(x)
  if ( is.null(pairwise.probabilities) ) pairwise.probabilities <- pairwise.probabilities(x)
  jobjRef <- E$s$do("org.ddahl.shallot.parameter.partition.MinBinder")$apply(pairwise.probabilities$jobjRef,x$jobjRef$samples,as.integer(max.subsets),as.integer(max.scans),as.logical(parallel))
  p <- partition2labels(jobjRef,x$names)
  attr(p,"proc.time") <- proc.time() - start.time
  p
}





# Confidence
confidence <- function(pairwise.probabilities, partition) {
  tmpObj <- pairwise.probabilities$jobjRef$confidenceComputations(labels2partition(partition))
  partition <- tmpObj$"_1"() + 1
  names(partition) <- pairwise.probabilities$names
  confidence <- tmpObj$"_2"()
  names(confidence) <- names(partition)
  confidence.matrix <- tmpObj$"_3"()
  dimnames(confidence.matrix) <- list(1:nrow(confidence.matrix),1:ncol(confidence.matrix))
  order <- tmpObj$"_4"() + 1L
  names(order) <- names(partition)
  exemplar <- tmpObj$"_5"() + 1L
  names(exemplar) <- 1:length(exemplar)
  result <- list(partition=partition,confidence=confidence,confidence.matrix=confidence.matrix,exemplar=exemplar,order=order,pairwise.probabilities=pairwise.probabilities)
  class(result) <- "shallot.confidence"
  result
}





# Confidence or pairs plot
plot.shallot.confidence <- function(x, partition=NULL, data=NULL, show.labels=length(x$partition)<=50, ...) {
  if ( ! is.null(data) ) {
    if ( ! is.null(partition) ) stop("Clustering must be 'NULL' for pairs plot.")
    i <- x$exemplar[x$partition]
    c <- rainbow(length(x$exemplar))[x$partition]
    panelFnc <- function(x0,y0,...) {
      points(x0,y0,col=c,pch=19,...)
      segments(x0,y0,x0[i],y0[i],col=c,...)
      points(x0[x$exemplar],y0[x$exemplar],pch=22,bg="white",cex=2,...)
    }
    pairs(data,panel=panelFnc)
    return(invisible())
  }
  if ( is.null(partition) ) {
    partition <- x$partition
    o <- x$order
  } else {
    o <- order(partition)
  }
  pm <- E$s$do("org.ddahl.shallot.r.RInterface")$rotateForConfidencePlot(x$pairwise.probabilities$jobjRef,o)
  n <- nrow(pm)
  sizes <- rle(partition[o])$lengths
  cuts <- cumsum(sizes)
  centers <- ( c(0,cuts[-length(cuts)]) + cuts ) / 2
  cuts <- cuts[-length(cuts)]
  labels <- rle(partition[o])$values
  if ( show.labels ) {
    mymai <- c(1.5,0.5,0.5,1.5)
    cexscale <- 0.85 * 50 / length(partition)
  } else {
    mymai <- c(0,0,0,0)
    cexscale <- 1 * 50 / length(partition)
  }
  opar <- par(pty="s",mai=mymai)
  colors <- topo.colors(200)
  colors <- rev(heat.colors(200))
  image(x=1:n,y=1:n,z=pm,axes=FALSE,xlab="",ylab="",col=colors)
  box()
  abline(v=cuts+0.5,lwd=3)
  abline(h=n-cuts+0.5,lwd=3)
  text(centers+0.5,n-centers+0.5,labels,cex=0.8*cexscale*sizes)
  if ( show.labels ) {
    axisLabels <- if ( is.null(names(partition)) ) o
    else names(partition[o])
    axis(4,1:length(partition),rev(axisLabels),las=2,cex.axis=0.8*cexscale)
    axis(1,1:length(partition),axisLabels,las=2,cex.axis=0.8*cexscale)
    nn <- length(colors)
    bx <- par("usr")
    bx.cx <- c(bx[1] - 1.6 * (bx[2] - bx[1]) / 50, bx[1] - 0.3 * (bx[2] - bx[1]) / 50)
    bx.cy <- c(bx[3], bx[3])
    bx.sy <- (bx[4] - bx[3]) / nn
    xx <- rep(bx.cx, each=2)
    for ( i in 1:nn ) {
      yy <- c(bx.cy[1] + (bx.sy * (i - 1)),
              bx.cy[1] + (bx.sy * (i)),
              bx.cy[1] + (bx.sy * (i)),
              bx.cy[1] + (bx.sy * (i - 1)))
      polygon(xx,yy,col=colors[i],border=colors[i],xpd=TRUE)
    }
  }
  par(opar)
  invisible()
}




# Misc. functions

shallot.jar <- function(version="", others=TRUE) {
  allOthers <- if ( others ) {
    allYaAll   <- list.files(system.file("java",package="shallot"),full.names=TRUE)
    allShallot <- list.files(system.file("java",package="shallot"),pattern="shallot_.*-.*[0-9]\\.jar",full.names=TRUE)
    union(setdiff(allYaAll,allShallot),rscalaJar(version))
  } else c()
  if ( version == "" ) major.version <- ".*"
  else major.version = substr(version,1,4)
  shallot <- list.files(system.file("java",package="shallot"),pattern=paste("shallot_",major.version,'-.*[0-9]\\.jar',sep=""),full.names=TRUE)
  union(shallot,allOthers)
}


.onLoad <- function(libname, pkgname) {
  rscalaPackage(pkgname)
}

shallot.load <- function(...) {
  allShallotJars <- list.files(system.file("java",package=E$pkgname),pattern="shallot_.*.jar",full.names=TRUE)
  shallotJar <- list.files(system.file("java",package=E$pkgname),pattern=sprintf("shallot_%s-.*.jar",scalaInfo("2.11")$major.version),full.names=TRUE)
  rscalaLoad(union(setdiff(E$jars,allShallotJars),shallotJar),...)
  E$s$do("org.apache.commons.math3.random.EmpiricalDistribution")$new()  ## This circumvents a weird bug in Scala's class loader.
  intpSettings(E$s,quiet=TRUE)
  E$s[['env']]$mapper.nSubsets     <- E$s %.~% '(p: org.ddahl.shallot.parameter.partition.Partition[org.ddahl.shallot.REXP]) => p.nSubsets' 
  E$s[['env']]$mapper.entropy      <- E$s %.~% '(p: org.ddahl.shallot.parameter.partition.Partition[org.ddahl.shallot.REXP]) => p.entropy'
  E$s[['env']]$mapper.mass         <- E$s %.~% '(p: org.ddahl.shallot.AugmentedSample) => p._2'
  E$s[['env']]$mapper.discount     <- E$s %.~% '(p: org.ddahl.shallot.AugmentedSample) => p._3'
  E$s[['env']]$mapper.temperature  <- E$s %.~% '(p: org.ddahl.shallot.AugmentedSample) => p._5'
  E$s[['env']]$mapper.toLabelsWithParameters <- E$s %.~% '(p: org.ddahl.shallot.parameter.partition.Partition[org.ddahl.shallot.REXP]) => org.ddahl.shallot.r.RInterface.toLabelsWithParameters(p)'
  E$s[['env']]$mapper.toLabels     <- E$s %.~% '(x: (Array[Int], Array[org.ddahl.shallot.REXP])) => x._1'
  E$s[['env']]$mapper.toParameters <- E$s %.~% '(x: (Array[Int], Array[org.ddahl.shallot.REXP])) => x._2'
  invisible()
}

